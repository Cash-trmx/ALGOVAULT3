# ALGOEA Replit Starter

A mobile-responsive Flask dashboard starter for ALGOEA.

## Run on Replit
1. Create a new **Python** Replit project.
2. Upload/extract these files, preserving the `templates/` and `static/` folders.
3. Replit should install packages from `requirements.txt`.
4. Run `python main.py` (or configure the Run command to `python main.py`).
5. Open the web preview.

## Important
This project is a UI and API starter only. It does not connect to MetaTrader 5, provision Windows VPS terminals, process payments, authenticate customers, or execute trades. The dashboard intentionally shows no invented account or performance data.

Before production:
- Implement authentication and per-customer authorization.
- Add PostgreSQL persistence and secure secrets management.
- Integrate a payment provider using signed server-side webhooks.
- Build a Windows VPS agent that provisions isolated MT5 terminals.
- Deploy and validate the MQL5 EA in MetaEditor and MT5 Strategy Tester.
- Add command signing, audit logs, rate limits, monitoring and recovery.
- Define safe handling of open positions when a subscription expires.
- Obtain appropriate legal, financial-services and privacy advice for the countries where the service will operate.

Never put broker passwords, payment secrets, or VPS credentials in frontend code or public GitHub files.
