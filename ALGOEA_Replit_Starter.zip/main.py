from flask import Flask, render_template, jsonify, request
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deployment")

# This is a UI/API starter. It does NOT connect to MT5 or execute trades.
# Connect these routes to a secure backend and Windows VPS agent before launch.

@app.get("/")
def dashboard():
    return render_template("index.html")

@app.get("/api/status")
def status():
    return jsonify({
        "mode": "DEMO",
        "subscription": {"price": "R400/month", "status": "Not connected"},
        "trading": {"ea_status": "Not deployed", "terminal_status": "Not connected"},
        "account": {
            "balance": None,
            "equity": None,
            "floating_pnl": None,
            "currency": None
        },
        "notice": "Connect a verified MT5 terminal and VPS agent to display live data."
    })

@app.post("/api/ea/control")
def ea_control():
    payload = request.get_json(silent=True) or {}
    action = payload.get("action")
    if action not in ("start", "pause", "stop"):
        return jsonify({"ok": False, "error": "Invalid action"}), 400

    # TODO: Authenticate the customer, verify subscription, then send a
    # signed command to that customer's isolated Windows VPS agent.
    return jsonify({
        "ok": False,
        "status": "not_configured",
        "message": "VPS agent integration is required before EA controls can work."
    }), 501

@app.post("/api/settings")
def save_settings():
    payload = request.get_json(silent=True) or {}
    allowed = {"risk_mode", "fixed_lot", "risk_percent", "max_positions"}
    if not set(payload).issubset(allowed):
        return jsonify({"ok": False, "error": "Unsupported setting"}), 400

    # TODO: Validate limits server-side, save per customer, and sync to MT5.
    return jsonify({
        "ok": False,
        "status": "not_configured",
        "message": "Database and authenticated customer account are required."
    }), 501

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
