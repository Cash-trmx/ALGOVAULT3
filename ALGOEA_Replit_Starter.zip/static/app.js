async function postJSON(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await response.json();
  return {response, data};
}

document.querySelectorAll("[data-action]").forEach(button => {
  button.addEventListener("click", async () => {
    const message = document.getElementById("control-message");
    message.textContent = "Checking connection...";
    try {
      const {response, data} = await postJSON("/api/ea/control", {action: button.dataset.action});
      message.textContent = data.message || data.error || `Request returned ${response.status}.`;
    } catch {
      message.textContent = "Could not reach the ALGOEA backend.";
    }
  });
});

document.getElementById("save-settings").addEventListener("click", async () => {
  const message = document.getElementById("settings-message");
  const settings = {
    risk_mode: document.getElementById("risk-mode").value,
    fixed_lot: Number(document.getElementById("fixed-lot").value),
    risk_percent: Number(document.getElementById("risk-percent").value),
    max_positions: Number(document.getElementById("max-positions").value)
  };
  if (!(settings.fixed_lot > 0) || !(settings.risk_percent > 0 && settings.risk_percent <= 2) ||
      !(Number.isInteger(settings.max_positions) && settings.max_positions >= 1 && settings.max_positions <= 3)) {
    message.textContent = "Check your values. Risk must be above 0 and no more than 2%; maximum positions: 1–3.";
    return;
  }
  try {
    const {data} = await postJSON("/api/settings", settings);
    message.textContent = data.message || "Settings could not be saved.";
  } catch {
    message.textContent = "Could not reach the ALGOEA backend.";
  }
});

document.getElementById("billing-button").addEventListener("click", () => {
  alert("Payment checkout is not connected yet. Add a payment provider and server-side payment verification before accepting subscriptions.");
});
