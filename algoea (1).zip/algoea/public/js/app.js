'use strict';
(() => {
  // ---------- utils ----------
  const $ = (s, r = document) => r.querySelector(s);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const S = { me: null, cfg: null, unread: 0, ws: null };
  const money = (n, cur = 'ZAR') => n == null ? '–' : new Intl.NumberFormat('en-ZA', { style: 'currency', currency: cur || 'USD' }).format(n);
  const num = (n, d = 2) => n == null ? '–' : Number(n).toLocaleString('en-ZA', { minimumFractionDigits: d, maximumFractionDigits: d });
  const dt = t => t ? new Date(t).toLocaleString('en-ZA', { dateStyle: 'medium', timeStyle: 'short' }) : '–';
  const dd = t => t ? new Date(t).toLocaleDateString('en-ZA', { dateStyle: 'medium' }) : '–';
  const ago = t => { if (!t) return 'never'; const s = Math.round((Date.now() - t) / 1000); return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + 'm ago' : s < 86400 ? Math.round(s / 3600) + 'h ago' : Math.round(s / 86400) + 'd ago'; };
  const cls = n => n > 0 ? 'pos' : n < 0 ? 'neg' : '';
  function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => t.className = 'toast', 3800); }
  async function api(path, { method = 'GET', body } = {}) {
    const r = await fetch('/api' + path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
    let j = {}; try { j = await r.json(); } catch { /* */ }
    if (!r.ok) { const e = new Error(j.error || 'Request failed'); e.status = r.status; throw e; }
    return j;
  }
  const formData = f => { const o = {}; new FormData(f).forEach((v, k) => o[k] = v); f.querySelectorAll('input[type=checkbox]').forEach(c => o[c.name] = c.checked); return o; };

  // ---------- icons / logo ----------
  const LOGO = '<svg viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#15181b" stroke="#262b30"/><path d="M12 48 L32 12 L52 48 H42 L32 29 L22 48Z" fill="#39ff7a"/></svg>';

  // ---------- charts (dependency-free SVG) ----------
  function lineChart(pts) {
    if (pts.length < 2) return '<div class="empty">The equity curve appears after your EA reports account data.</div>';
    const W = 800, H = 240, p = { l: 56, r: 12, t: 14, b: 26 };
    const xs = pts.map(x => x.ts), ys = pts.map(x => x.equity);
    const x0 = Math.min(...xs), x1 = Math.max(...xs); let y0 = Math.min(...ys), y1 = Math.max(...ys);
    if (y0 === y1) { y0 -= 1; y1 += 1; }
    const pad = (y1 - y0) * .08; y0 -= pad; y1 += pad;
    const X = v => p.l + (v - x0) / (x1 - x0 || 1) * (W - p.l - p.r), Y = v => p.t + (1 - (v - y0) / (y1 - y0)) * (H - p.t - p.b);
    const d = pts.map((q, i) => (i ? 'L' : 'M') + X(q.ts).toFixed(1) + ' ' + Y(q.equity).toFixed(1)).join('');
    const area = d + `L${X(x1)} ${H - p.b}L${X(x0)} ${H - p.b}Z`;
    let grid = '';
    for (let i = 0; i <= 4; i++) { const v = y0 + (y1 - y0) * i / 4, y = Y(v); grid += `<line x1="${p.l}" x2="${W - p.r}" y1="${y}" y2="${y}" stroke="#262b30"/><text x="${p.l - 8}" y="${y + 4}" fill="#8b968f" font-size="11" text-anchor="end">${num(v, 0)}</text>`; }
    const lab = t => new Date(t).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' });
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Equity curve">
      <defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#39ff7a" stop-opacity=".35"/><stop offset="1" stop-color="#39ff7a" stop-opacity="0"/></linearGradient></defs>
      ${grid}<path d="${area}" fill="url(#ga)"/><path d="${d}" fill="none" stroke="#39ff7a" stroke-width="2" vector-effect="non-scaling-stroke"/>
      <text x="${p.l}" y="${H - 6}" fill="#8b968f" font-size="11">${lab(x0)}</text><text x="${W - p.r}" y="${H - 6}" fill="#8b968f" font-size="11" text-anchor="end">${lab(x1)}</text></svg>`;
  }
  function barChart(rows, fmtLabel) {
    if (!rows.some(r => r.pnl !== 0)) return '<div class="empty">No closed trades in this period yet.</div>';
    const W = 800, H = 240, p = { l: 56, r: 12, t: 14, b: 26 };
    const mx = Math.max(...rows.map(r => Math.abs(r.pnl)), 1), zero = p.t + (H - p.t - p.b) / 2, half = (H - p.t - p.b) / 2 - 4;
    const bw = (W - p.l - p.r) / rows.length;
    const bars = rows.map((r, i) => { const h = Math.abs(r.pnl) / mx * half, x = p.l + i * bw + bw * .15; return `<rect x="${x.toFixed(1)}" y="${(r.pnl >= 0 ? zero - h : zero).toFixed(1)}" width="${(bw * .7).toFixed(1)}" height="${Math.max(h, r.pnl ? 1 : 0).toFixed(1)}" rx="2" fill="${r.pnl >= 0 ? '#39ff7a' : '#ff5266'}"><title>${esc(fmtLabel(r.t))}: ${num(r.pnl)}</title></rect>`; }).join('');
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Performance"><line x1="${p.l}" x2="${W - p.r}" y1="${zero}" y2="${zero}" stroke="#3a4249"/>
      <text x="${p.l - 8}" y="${p.t + 8}" fill="#8b968f" font-size="11" text-anchor="end">+${num(mx, 0)}</text><text x="${p.l - 8}" y="${H - p.b}" fill="#8b968f" font-size="11" text-anchor="end">-${num(mx, 0)}</text>${bars}
      <text x="${p.l}" y="${H - 6}" fill="#8b968f" font-size="11">${esc(fmtLabel(rows[0].t))}</text><text x="${W - p.r}" y="${H - 6}" fill="#8b968f" font-size="11" text-anchor="end">${esc(fmtLabel(rows[rows.length - 1].t))}</text></svg>`;
  }

  // ---------- shell ----------
  const publicLinks = [['home', 'Home'], ['about', 'About'], ['features', 'Features'], ['iron-scalping', 'IRON SCALPING'], ['pricing', 'Pricing'], ['support', 'Support']];
  const appLinks = [['dashboard', 'Dashboard'], ['hosting', 'Hosting'], ['mt5', 'MT5 Accounts'], ['pricing', 'Billing'], ['support', 'Support'], ['account', 'Account']];
  function renderShell(page) {
    const links = (S.me ? appLinks.concat(S.me.is_admin ? [['admin', 'Admin']] : []) : publicLinks).map(([h, l]) =>
      `<a href="#/${h}" class="${page === h ? 'on' : ''}">${l}${h === 'account' && S.unread ? `<span class="badge-n">${S.unread}</span>` : ''}</a>`).join('');
    $('#top').innerHTML = `<div class="wrap"><nav class="nav" id="nav"><a class="logo" href="#/home">${LOGO}<span>ALGO<b>EA</b></span></a>
      <div class="links">${links}</div>
      <div class="navr">${S.me ? `<button class="btn sm" data-act="logout">Log out</button>` : `<a class="btn sm" href="#/login">Log in</a><a class="btn sm pri" href="#/register">Get started</a>`}</div>
      <button class="burger" data-act="burger" aria-label="Menu">☰</button></nav></div>`;
    $('#foot').innerHTML = `<div class="wrap"><div class="cols"><div><a class="logo" href="#/home">${LOGO}<span>ALGO<b>EA</b></span></a><p class="sm" style="max-width:360px;margin-top:10px">Automated Forex EA hosting for MetaTrader 5.</p></div>
      <div><a href="#/features">Features</a><a href="#/iron-scalping">IRON SCALPING</a><a href="#/pricing">Pricing</a><a href="#/support">Support</a></div>
      <div><a href="#/about">About</a><a href="#/terms">Terms and Conditions</a><a href="#/privacy">Privacy Policy</a></div></div>
      <p class="sm" style="margin-top:22px">Risk warning: automated trading involves substantial financial risk. Past performance does not guarantee future results and profits are not guaranteed. You may lose some or all of your capital. ALGOEA does not provide financial advice.</p>
      <p class="sm">© ${new Date().getFullYear()} ALGOEA. All rights reserved.</p></div>`;
  }

  // ---------- public pages ----------
  const DISC = '<div class="disc"><b>Risk disclaimer:</b> Automated trading involves financial risk. Profits are not guaranteed and you can lose money. Only trade with capital you can afford to lose.</div>';
  const featureList = [
    ['⚡', 'Automated EA deployment', 'Connect your MT5 account and ALGOEA installs, configures and starts IRON SCALPING in an isolated terminal for you.'],
    ['☁', 'Always-on cloud hosting', 'Your terminal runs on managed Windows VPS infrastructure with automatic restart after unexpected shutdowns.'],
    ['📊', 'Real-time dashboard', 'Balance, equity, floating P/L, drawdown and open trades, read directly from your MT5 account.'],
    ['🎛', 'Remote EA controls', 'Start, stop, restart and enable auto trading from your phone, anywhere.'],
    ['🛡', 'Built-in risk protection', 'Daily loss limit, drawdown limit, spread and volatility filters, and trading session control.'],
    ['🔒', 'Secure by design', 'MT5 passwords are encrypted at rest, isolated per customer and never shown to administrators.']
  ];
  const faqs = [
    ['Is profit guaranteed?', 'No. Trading is risky and results vary. ALGOEA provides hosting and automation tools, not guaranteed returns.'],
    ['What do I need to start?', 'An ALGOEA PREMIUM subscription and an MT5 account with a broker that offers XAUUSD (a demo account is recommended first).'],
    ['Can administrators see my password?', 'No. Your MT5 password is encrypted and only decrypted for the hosting agent that runs your terminal.'],
    ['What happens if my subscription expires?', 'Your EA is stopped automatically and access is suspended until you renew. Existing open trades remain with your broker, so manage them directly.'],
    ['Which platform does the EA run on?', 'MetaTrader 5, with XAUUSD as the primary instrument.'],
    ['Can I cancel anytime?', 'Yes. Turn off automatic renewal from the Billing page. Access continues to the end of the paid period.']
  ];
  const pages = {};
  pages.home = () => `<section class="hero fade"><div class="wrap"><span class="tag">AUTOMATED FOREX · EA HOSTING · MT5</span>
    <h1>YOUR TRADING.<span>AUTOMATED. HOSTED. CONTROLLED.</span></h1>
    <p class="lead">Experience professional automated Forex trading with ALGOEA. Host your Expert Advisors, deploy IRON SCALPING and manage your MT5 trading infrastructure directly from your phone.</p>
    <div class="cta"><a class="btn pri" href="#/register">GET STARTED</a><a class="btn" href="#/features">EXPLORE FEATURES</a></div></div></section>
    <section class="sec"><div class="wrap"><h2>Everything you need to run an EA properly</h2><p style="margin-bottom:26px">One platform for hosting, monitoring and control.</p>
    <div class="grid g3">${featureList.map(f => `<div class="card"><div class="ico">${f[0]}</div><h3>${f[1]}</h3><p>${f[2]}</p></div>`).join('')}</div></div></section>
    <section class="sec"><div class="wrap"><div class="grid g2" style="align-items:center"><div><span class="tag" style="display:inline-block;border:1px solid rgba(57,255,122,.35);color:var(--g);padding:4px 12px;border-radius:99px;font-size:.75rem;font-weight:700;margin-bottom:14px">BUILT IN</span><h2>ALGOEA IRON SCALPING</h2>
    <p>A multi-timeframe XAUUSD strategy for MetaTrader 5: higher-timeframe trend confirmation, M15 and M5 market structure, optional M1 entries, and layered risk controls.</p><div class="cta" style="margin-top:20px"><a class="btn" href="#/iron-scalping">Learn more</a></div></div>
    <div class="card"><ul class="ck"><li>Higher-timeframe trend filter</li><li>M15 + M5 structure confirmation</li><li>Spread, volatility and session filters</li><li>Stop-loss, take-profit, trailing and break-even</li><li>Daily loss and max drawdown protection</li><li>Fixed-lot or percentage-risk sizing</li></ul></div></div></div></section>
    <section class="sec"><div class="wrap"><h2 class="center">How it works</h2><div class="grid g4 steps" style="margin-top:26px">
    ${[['Subscribe', 'Choose ALGOEA PREMIUM. Your account activates once payment is verified.'], ['Connect MT5', 'Add your MT5 login and broker server. Credentials are encrypted.'], ['Set your risk', 'Configure lot size, loss limits and sessions within platform limits.'], ['Deploy & monitor', 'One tap deploys IRON SCALPING. Track it live from your phone.']].map(s => `<div class="card"><h3>${s[0]}</h3><p>${s[1]}</p></div>`).join('')}</div></div></section>
    ${pricingBlock()}
    <section class="sec"><div class="wrap" style="max-width:820px"><h2 class="center">Frequently asked questions</h2><div style="margin-top:24px">${faqs.map(f => `<details><summary>${f[0]}</summary><p>${f[1]}</p></details>`).join('')}</div></div></section>
    <section class="sec"><div class="wrap"><div class="card center"><h2>Need help?</h2><p style="margin-bottom:18px">Our support team assists with setup, billing and hosting questions.</p><a class="btn pri" href="#/support">Contact support</a></div><div style="margin-top:24px">${DISC}</div></div></section>`;
  const priceStr = () => S.cfg ? money(S.cfg.plan.price_cents / 100, S.cfg.plan.currency).replace(/ /g, '') : 'R300.00';
  function pricingBlock() {
    return `<section class="sec" id="pricing"><div class="wrap" style="max-width:520px"><div class="card hl center"><span class="pill ok">ONE SIMPLE PLAN</span><h3 style="margin-top:14px">ALGOEA PREMIUM</h3>
      <div class="price">${priceStr().replace('.00', '')}<small> / month</small></div>
      <ul class="ck" style="text-align:left;max-width:320px;margin:18px auto"><li>Full access to the ALGOEA hosting platform</li><li>Built-in IRON SCALPING strategy</li><li>MT5 integration</li><li>Automated EA deployment</li><li>Real-time trading dashboard</li><li>Trading performance monitoring</li><li>Remote EA controls</li><li>Customer support</li></ul>
      <a class="btn pri" href="#/${S.me ? 'pricing' : 'register'}" style="width:100%">${S.me ? 'Manage subscription' : 'GET STARTED'}</a><p class="sm" style="margin-top:12px">Billed monthly. Renews automatically. Cancel anytime.</p></div></div></section>`;
  }
  pages.about = () => `<div class="wrap page doc fade" style="max-width:820px"><h2>About ALGOEA</h2><p>ALGOEA is an automated Forex trading technology platform that hosts MetaTrader 5 Expert Advisors in the cloud. We remove the burden of running a personal VPS: you connect your own broker account, choose your risk limits, and ALGOEA runs and monitors your EA around the clock.</p>
    <h3>Your account, your broker</h3><p>Funds always stay with your broker. ALGOEA never holds client money. The platform connects to your MT5 account only to run and report on your EA.</p>
    <h3>Transparency first</h3><p>Every figure in your dashboard comes from your real MT5 account. We do not show simulated trades or fabricated profits.</p><div style="margin-top:24px">${DISC}</div></div>`;
  pages.features = () => `<div class="wrap page fade"><h2>Platform features</h2><p style="margin-bottom:24px">Built to feel like a professional trading operations desk.</p><div class="grid g3">${featureList.concat([
    ['🧩', 'Isolated MT5 terminals', 'Each customer gets a separate terminal and data folder, so accounts never mix.'],
    ['🩺', 'Health monitoring', 'CPU, RAM, connection state and EA error logs, with automatic terminal restart.'],
    ['💳', 'Simple billing', 'Monthly subscription with payment history, automatic renewal and clear expiry.']]).map(f => `<div class="card"><div class="ico">${f[0]}</div><h3>${f[1]}</h3><p>${f[2]}</p></div>`).join('')}</div><div style="margin-top:28px">${DISC}</div></div>`;
  pages['iron-scalping'] = () => `<div class="wrap page fade"><h2>ALGOEA IRON SCALPING</h2><p style="max-width:720px;margin-bottom:24px">A multi-timeframe Expert Advisor for MetaTrader 5, primarily designed for XAUUSD, integrated directly into the ALGOEA hosting pipeline.</p>
    <div class="grid g2"><div class="card"><h3>Market analysis</h3><ul class="ck"><li>Higher-timeframe trend confirmation</li><li>M15 and M5 market structure confirmation</li><li>Optional M1 scalping entries</li><li>Smart entry on structure breaks in trend direction</li></ul></div>
    <div class="card"><h3>Trade management</h3><ul class="ck"><li>Automated stop-loss and take-profit</li><li>Trailing stop-loss</li><li>Break-even functionality</li><li>Fixed-lot or percentage-risk sizing</li></ul></div>
    <div class="card"><h3>Filters</h3><ul class="ck"><li>Spread filter</li><li>Volatility (ATR) filter</li><li>Trading session filter</li></ul></div>
    <div class="card"><h3>Account protection</h3><ul class="ck"><li>Maximum daily loss protection</li><li>Maximum drawdown protection</li><li>Platform-enforced risk caps</li></ul></div></div>
    <div class="cta" style="margin:26px 0"><a class="btn pri" href="#/register">GET STARTED</a></div>${DISC}<p class="sm" style="margin-top:12px">Test on a demo account first. No strategy can guarantee profit.</p></div>`;
  pages.pricing = async () => {
    if (!S.me) return `<div class="wrap page fade"><h2 class="center">Pricing</h2>${pricingBlock()}<div class="wrap" style="max-width:720px">${DISC}</div></div>`;
    const b = await api('/billing');
    const sub = b.subscription, active = S.me.subscription_active;
    return `<div class="wrap page fade"><div class="ph"><h2>Billing</h2></div><div class="grid g2">
      <div class="card"><h3>ALGOEA PREMIUM</h3><div class="price">${money(b.plan.price_cents / 100, b.plan.currency).replace(/ /g, '').replace('.00', '')}<small> / month</small></div>
      <dl class="kv" style="margin:14px 0"><dt>Status</dt><dd><span class="pill ${active ? 'ok' : 'bad'}">${active ? 'ACTIVE' : (sub?.status || 'NO SUBSCRIPTION').toUpperCase()}</span></dd>
      <dt>${active ? 'Renews / ends' : 'Ended'}</dt><dd>${sub?.ends_at ? dd(sub.ends_at) : '–'}</dd><dt>Auto-renew</dt><dd>${sub ? (sub.auto_renew ? 'On' : 'Off') : '–'}</dd></dl>
      <div class="ctl"><button class="btn pri" data-act="checkout">${active ? 'Pay for next month' : 'Subscribe now'}</button>${active && sub.auto_renew ? '<button class="btn" data-act="cancel-renew">Cancel auto-renewal</button>' : ''}</div>
      ${b.payments_configured ? '' : '<p class="hint" style="margin-top:12px">Online payment is not enabled yet. Contact support to subscribe by EFT; your account is activated once the payment is verified.</p>'}
      <p class="hint" style="margin-top:10px">Your account activates only after payment is verified. When a subscription expires, your EA stops automatically.</p></div>
      <div class="card"><h3>Payment history</h3>${b.payments.length ? `<div class="tw"><table><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr>${b.payments.map(p => `<tr><td>${dt(p.created_at)}</td><td>${money(p.amount_cents / 100, p.currency)}</td><td>${esc(p.provider)}</td><td><span class="pill ${p.status === 'complete' ? 'ok' : p.status === 'pending' ? 'warn' : 'bad'}">${esc(p.status)}</span></td></tr>`).join('')}</table></div>` : '<div class="empty">No payments yet.</div>'}</div></div></div>`;
  };
  const docPage = (title, body) => `<div class="wrap page doc fade" style="max-width:820px"><h2>${title}</h2><p class="sm">Last updated: 7 November 2026. This is a template and must be reviewed by a qualified South African attorney before launch.</p>${body}</div>`;
  pages.terms = () => docPage('Terms and Conditions', `
    <h3>1. Service</h3><p>ALGOEA provides cloud hosting and automation tooling for MetaTrader 5 Expert Advisors. ALGOEA is a technology provider. It is not a financial services provider and does not give financial advice.</p>
    <h3>2. Risk</h3><p>Trading leveraged products such as Forex and gold carries a high risk of loss. Profits are not guaranteed. You are solely responsible for your trading decisions, broker relationship and risk settings.</p>
    <h3>3. Subscription and payment</h3><p>ALGOEA PREMIUM is charged monthly and renews automatically until cancelled. Accounts activate only after payment is verified. When a subscription expires, your EA is stopped and access is suspended. Open positions remain with your broker and must be managed by you.</p>
    <h3>4. Your MT5 credentials</h3><p>You authorise ALGOEA to use your MT5 login solely to run your EA. Use an account you control and, where possible, start on a demo account. You are responsible for the security of your broker account.</p>
    <h3>5. Availability</h3><p>We aim for high availability but do not guarantee uninterrupted service. Outages at ALGOEA, your broker or the internet may affect trading.</p>
    <h3>6. Acceptable use</h3><p>You may not attempt to access other customers' data, interfere with the platform or use it for unlawful activity. We may suspend accounts that breach these terms.</p>
    <h3>7. Liability</h3><p>To the maximum extent permitted by law, ALGOEA is not liable for trading losses or indirect damages arising from use of the platform.</p>
    <h3>8. Contact</h3><p>Use the Support page for any questions about these terms.</p>`);
  pages.privacy = () => docPage('Privacy Policy', `
    <h3>Information we collect</h3><p>Account details (name, email, phone), subscription and payment records, MT5 account details you provide (login, broker server), and trading data read from your MT5 account (balance, equity, trades) to power your dashboard.</p>
    <h3>How we protect it</h3><p>Passwords are hashed. MT5 passwords are encrypted at rest and only decrypted for the hosting agent running your terminal. Administrators cannot view them. Connections use HTTPS.</p>
    <h3>How we use it</h3><p>To operate the service, process payments through our payment provider, provide support and keep the platform secure. We do not sell personal information.</p>
    <h3>Your rights (POPIA)</h3><p>You may request access to, correction of, or deletion of your personal information by contacting support.</p>
    <h3>Retention</h3><p>Trading records are kept while your account is active. Removing an MT5 account deletes its stored credentials.</p>`);

  // ---------- auth pages ----------
  const authForm = (title, act, fields, btn, extra = '') => `<div class="form card fade"><h2>${title}</h2><form data-form="${act}" novalidate>${fields}<div class="err" id="err"></div><button class="btn pri" style="width:100%;margin-top:8px">${btn}</button></form>${extra}</div>`;
  pages.login = () => authForm('Log in', 'login', `<label>Email</label><input name="email" type="email" autocomplete="email" required><label>Password</label><input name="password" type="password" autocomplete="current-password" required>`, 'Log in',
    '<p class="sm center" style="margin-top:16px"><a href="#/forgot">Forgot password?</a> · <a href="#/register">Create account</a></p>');
  pages.register = () => authForm('Create your account', 'register', `<label>Full name</label><input name="name" autocomplete="name" required><label>Email</label><input name="email" type="email" autocomplete="email" required><label>Password</label><input name="password" type="password" autocomplete="new-password" minlength="10" required><div class="hint">At least 10 characters, with letters and numbers.</div>
    <div class="chk"><input type="checkbox" name="accept_terms" id="at"><label for="at">I accept the <a href="#/terms">Terms</a> and <a href="#/privacy">Privacy Policy</a> and understand trading is risky.</label></div>`, 'Create account',
    '<p class="sm center" style="margin-top:16px">Already registered? <a href="#/login">Log in</a></p>');
  pages.forgot = () => authForm('Forgot password', 'forgot', '<label>Email</label><input name="email" type="email" required>', 'Send reset link');
  pages.reset = (q) => authForm('Choose a new password', 'reset', `<input type="hidden" name="token" value="${esc(q.get('token'))}"><label>New password</label><input name="password" type="password" autocomplete="new-password" minlength="10" required>`, 'Reset password');
  pages.verify = async (q) => {
    let msg, ok = false;
    try { await api('/auth/verify', { method: 'POST', body: { token: q.get('token') } }); ok = true; msg = 'Your email is verified. You can now log in.'; } catch (e) { msg = e.message; }
    return `<div class="form card center fade"><h2>${ok ? 'Email verified' : 'Verification failed'}</h2><p style="margin:12px 0 20px">${esc(msg)}</p><a class="btn pri" href="#/login">Go to login</a></div>`;
  };

  // ---------- account ----------
  pages.account = async () => {
    const [n, ss] = await Promise.all([api('/notifications'), api('/me/sessions')]);
    await api('/notifications/read', { method: 'POST', body: {} }); S.unread = 0;
    const u = S.me;
    return `<div class="wrap page fade"><div class="ph"><h2>Account</h2></div><div class="grid g2">
    <div class="card"><h3>Profile</h3><form data-form="profile"><label>Name</label><input name="name" value="${esc(u.name)}" required><label>Phone</label><input name="phone" value="${esc(u.phone || '')}"><label>Email</label><input value="${esc(u.email)}" disabled><div class="err"></div><button class="btn pri">Save profile</button></form></div>
    <div class="card"><h3>Security</h3><form data-form="password"><label>Current password</label><input name="current_password" type="password" autocomplete="current-password" required><label>New password</label><input name="new_password" type="password" autocomplete="new-password" minlength="10" required><div class="err"></div><div class="ctl"><button class="btn pri">Change password</button><button type="button" class="btn dng" data-act="logout-all">Log out from all devices</button></div></form></div>
    <div class="card"><h3>Active sessions</h3><div class="tw"><table><tr><th>Started</th><th>IP</th><th>Device</th></tr>${ss.sessions.map(s => `<tr><td>${dt(s.created_at)}${s.current ? ' <span class="pill ok">this device</span>' : ''}</td><td>${esc(s.ip)}</td><td>${esc((s.user_agent || '').slice(0, 40))}</td></tr>`).join('')}</table></div></div>
    <div class="card"><h3>Notifications</h3>${n.notifications.length ? n.notifications.map(x => `<div style="padding:8px 0;border-bottom:1px solid var(--line)"><b>${esc(x.title)}</b><div class="sm mut">${esc(x.body)} · ${ago(x.created_at)}</div></div>`).join('') : '<div class="empty">No notifications.</div>'}</div></div></div>`;
  };

  // ---------- dashboard ----------
  let dashState = { account: null, perf: 'daily', data: null };
  const STATUS = {
    running: ['Running', 'ok'], stopped: ['Stopped', 'warn'], error: ['Error', 'bad'], deploying: ['Deploying', 'warn'], queued: ['Queued', 'warn'],
    disconnected: ['Disconnected', 'bad'], not_deployed: ['Not deployed', 'warn']
  };
  const pill = (txt, k) => `<span class="pill ${k}">${esc(txt)}</span>`;
  const statusPill = s => { const [t, k] = STATUS[s] || [s, 'warn']; return pill(t, k); };
  const needSub = () => `<div class="card center" style="margin-bottom:18px"><h3>Subscription required</h3><p style="margin:8px 0 14px">An active ALGOEA PREMIUM subscription is needed to use the platform.</p><a class="btn pri" href="#/pricing">Subscribe</a></div>`;
  pages.dashboard = async (q) => {
    const j = await api('/dashboard' + (dashState.account ? '?account=' + dashState.account : ''));
    let h = `<div class="wrap page fade"><div class="ph"><div><h2>Dashboard</h2><p class="sm">Live data from your MT5 account${S.me.subscription_active ? '' : ''}</p></div>`;
    if (j.accounts.length > 1) h += `<select id="acctSel" style="width:auto">${j.accounts.map(a => `<option value="${a.id}" ${a.id === j.data.account.id ? 'selected' : ''}>${esc(a.login)} · ${esc(a.server)}</option>`).join('')}</select>`;
    h += '</div>';
    if (q.get('paid')) h += '<div class="card" style="margin-bottom:16px">Thank you. We will activate your subscription as soon as the payment provider confirms payment.</div>';
    if (!S.me.subscription_active) h += needSub();
    if (!j.data) return h + `<div class="card center"><h3>No MT5 account connected</h3><p style="margin:8px 0 14px">Connect your MT5 account to start.</p><a class="btn pri" href="#/mt5">Connect MT5 account</a></div></div>`;
    const d = j.data, L = d.live, cur = L?.currency || 'USD';
    dashState.data = d; dashState.account = d.account.id;
    const st = d.stats;
    const vStat = (l, v, c = '') => `<div class="card stat"><div class="l">${l}</div><div class="v ${c}">${v}</div></div>`;
    const accStatus = d.account.status === 'connected' && L?.connected ? ['Connected', 'ok'] : d.account.status === 'error' ? ['Error', 'bad'] : d.account.status === 'pending' ? ['Pending', 'warn'] : ['Disconnected', 'bad'];
    const eaS = d.ea ? d.ea.status : 'not_deployed';
    h += `<div class="card" style="margin-bottom:16px"><div class="grid g4" style="align-items:center">
      <div><div class="stat"><div class="l">EA status</div></div>${statusPill(eaS)}${d.ea?.last_error ? `<div class="sm neg" style="margin-top:6px">${esc(d.ea.last_error)}</div>` : ''}</div>
      <div><div class="stat"><div class="l">MT5 account</div></div>${pill(accStatus[0], accStatus[1])}</div>
      <div><div class="stat"><div class="l">VPS status</div></div>${d.vps ? pill(d.vps.status === 'online' ? 'Connected' : 'Disconnected', d.vps.status === 'online' ? 'ok' : 'bad') + `<span class="sm mut"> ${esc(d.vps.name)}</span>` : pill('Not assigned', 'warn')}</div>
      <div><div class="stat"><div class="l">Broker</div></div><b>${esc(d.account.broker || '–')}</b><div class="sm mut">${esc(d.account.login)} · ${esc(d.account.server)}</div></div></div></div>`;
    if (!L) h += `<div class="empty" style="margin-bottom:16px">No account data received yet. ${d.ea ? 'Waiting for your EA to report from the VPS.' : 'Deploy IRON SCALPING from the MT5 Accounts page.'}</div>`;
    h += `<div class="grid g4" style="margin-bottom:16px">${vStat('Balance', L ? money(L.balance, cur) : '–')}${vStat('Equity', L ? money(L.equity, cur) : '–')}${vStat('Floating P/L', L ? money(L.floating, cur) : '–', cls(L?.floating))}${vStat('Daily P/L', st.daily_pnl == null ? '–' : money(st.daily_pnl, cur), cls(st.daily_pnl))}
      ${vStat('Total profit', st.total_profit == null ? '–' : money(st.total_profit, cur), cls(st.total_profit))}${vStat('Active trades', L ? L.positions.length : '–')}${vStat('Current drawdown', st.drawdown_pct == null ? '–' : st.drawdown_pct + '%')}${vStat('Auto trading', d.ea ? (d.ea.autotrading ? 'Enabled' : 'Disabled') : '–')}</div>`;
    if (d.ea) h += `<div class="card" style="margin-bottom:16px"><h3>EA controls</h3><div class="ctl"><button class="btn pri" data-act="ea" data-id="${d.ea.id}" data-a="start">START EA</button><button class="btn dng" data-act="ea" data-id="${d.ea.id}" data-a="stop">STOP EA</button><button class="btn" data-act="ea" data-id="${d.ea.id}" data-a="restart">RESTART EA</button><button class="btn" data-act="ea" data-id="${d.ea.id}" data-a="enable_autotrading">ENABLE AUTO TRADING</button></div></div>`;
    h += `<div class="grid g2" style="margin-bottom:16px"><div class="card"><h3>Equity curve</h3><p class="sm" style="margin-bottom:8px">Last 30 days</p>${lineChart(d.equity_curve)}</div>
      <div class="card"><h3>Performance</h3><div class="tabs" id="perfTabs">${['daily', 'weekly', 'monthly'].map(k => `<button data-act="perf" data-k="${k}" class="${dashState.perf === k ? 'on' : ''}">${k[0].toUpperCase() + k.slice(1)}</button>`).join('')}</div><div id="perfChart">${perfChart(d)}</div></div></div>`;
    h += `<div class="card" style="margin-bottom:16px"><h3>Open trades</h3>${L && L.positions.length ? `<div class="tw"><table><tr><th>Ticket</th><th>Symbol</th><th>Type</th><th>Lots</th><th>Open</th><th>SL</th><th>TP</th><th>P/L</th></tr>${L.positions.map(p => `<tr><td>${esc(p.ticket)}</td><td>${esc(p.symbol)}</td><td>${esc(p.type)}</td><td>${num(p.volume)}</td><td>${num(p.open_price, 3)}</td><td>${p.sl ? num(p.sl, 3) : '–'}</td><td>${p.tp ? num(p.tp, 3) : '–'}</td><td class="${cls(p.profit)}">${num(p.profit)}</td></tr>`).join('')}</table></div>` : '<div class="empty">No open trades.</div>'}</div>`;
    h += `<div class="card"><h3>Trading history</h3>${d.history.length ? `<div class="tw"><table><tr><th>Closed</th><th>Symbol</th><th>Type</th><th>Lots</th><th>Open</th><th>Close</th><th>Net P/L</th></tr>${d.history.map(t => `<tr><td>${dt(t.close_time)}</td><td>${esc(t.symbol)}</td><td>${esc(t.type)}</td><td>${num(t.volume)}</td><td>${num(t.open_price, 3)}</td><td>${num(t.close_price, 3)}</td><td class="${cls(t.profit + t.swap + t.commission)}">${num(t.profit + t.swap + t.commission)}</td></tr>`).join('')}</table></div>` : '<div class="empty">No closed trades yet.</div>'}</div>`;
    return h + `<p class="sm" style="margin-top:18px">All figures are read from your MT5 account. Updated ${L ? ago(L.updated_at) : 'never'}.</p></div>`;
  };
  function perfChart(d) {
    const k = dashState.perf, rows = d.performance[k];
    const f = k === 'monthly' ? t => new Date(t).toLocaleDateString('en-ZA', { month: 'short', year: '2-digit' }) : t => new Date(t).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' });
    return barChart(rows, f);
  }

  // ---------- MT5 ----------
  function riskFields(v = S.cfg.defaults, caps = S.cfg.caps) {
    const n = (name, label, step, min, max, hint) => `<div><label>${label}</label><input name="${name}" type="number" step="${step}" min="${min}" max="${max}" value="${v[name]}" required>${hint ? `<div class="hint">${hint}</div>` : ''}</div>`;
    return `<div class="frow"><div><label>Lot mode</label><select name="lot_mode"><option value="percent" ${v.lot_mode === 'percent' ? 'selected' : ''}>Percentage risk</option><option value="fixed" ${v.lot_mode === 'fixed' ? 'selected' : ''}>Fixed lot</option></select></div>
      ${n('fixed_lot', 'Fixed lot size', 0.01, 0.01, caps.fixed_lot, 'Max ' + caps.fixed_lot)}${n('risk_percent', 'Risk per trade (%)', 0.1, 0.1, caps.risk_percent, 'Max ' + caps.risk_percent + '%')}
      ${n('rr', 'Take-profit ratio (R:R)', 0.1, 0.5, 5)}${n('max_daily_loss_pct', 'Max daily loss (%)', 0.5, 0.5, caps.daily_loss_pct, 'Max ' + caps.daily_loss_pct + '%')}${n('max_drawdown_pct', 'Max drawdown (%)', 1, 1, caps.drawdown_pct, 'Max ' + caps.drawdown_pct + '%')}
      ${n('max_spread_points', 'Max spread (points)', 1, 5, caps.max_spread_points, 'Max ' + caps.max_spread_points)}${n('max_open_trades', 'Max open trades', 1, 1, caps.max_open_trades, 'Max ' + caps.max_open_trades)}
      ${n('session_start_hour', 'Session start (broker hour)', 1, 0, 23)}${n('session_end_hour', 'Session end (broker hour)', 1, 1, 24)}</div>
      <div class="chk"><input type="checkbox" name="use_m1_entries" id="m1" ${v.use_m1_entries ? 'checked' : ''}><label for="m1">Enable M1 scalping entries</label></div>
      <div class="chk"><input type="checkbox" name="use_trailing" id="tr" ${v.use_trailing ? 'checked' : ''}><label for="tr">Trailing stop-loss</label></div>
      <div class="chk"><input type="checkbox" name="use_breakeven" id="be" ${v.use_breakeven ? 'checked' : ''}><label for="be">Break-even</label></div>`;
  }
  const settingsFrom = f => { const o = formData(f); const s = {}; for (const k of ['lot_mode', 'fixed_lot', 'risk_percent', 'rr', 'max_daily_loss_pct', 'max_drawdown_pct', 'max_spread_points', 'max_open_trades', 'session_start_hour', 'session_end_hour', 'use_m1_entries', 'use_trailing', 'use_breakeven']) s[k] = o[k]; return s; };
  pages.mt5 = async () => {
    const { accounts } = await api('/mt5');
    const instr = S.cfg.instruments.map(i => `<option>${esc(i)}</option>`).join('');
    return `<div class="wrap page fade"><div class="ph"><div><h2>MT5 accounts</h2><p class="sm">Connect your account, set your risk and deploy IRON SCALPING.</p></div></div>
    ${S.me.subscription_active ? '' : needSub()}
    ${accounts.map(a => `<div class="card" style="margin-bottom:16px"><div class="ph" style="margin-bottom:8px"><div><h3>${esc(a.login)} <span class="mut sm">· ${esc(a.server)}</span></h3><div class="sm mut">${esc(a.broker || 'Broker pending')} · ${esc(a.instrument)}</div></div>
      <div>${pill(a.status === 'connected' ? 'Connected' : a.status === 'error' ? 'Error' : a.status === 'pending' ? 'Pending' : 'Disconnected', a.status === 'connected' ? 'ok' : a.status === 'error' ? 'bad' : 'warn')} ${a.deployment ? statusPill(a.deployment.status) : pill('Not deployed', 'warn')}</div></div>
      <div class="ctl" style="margin-bottom:12px"><button class="btn pri" data-act="deploy" data-id="${a.id}">${a.deployment ? 'Redeploy IRON SCALPING' : 'Deploy IRON SCALPING'}</button><button class="btn dng sm" data-act="rm-acct" data-id="${a.id}">Remove account</button></div>
      <details><summary>Risk settings</summary><form data-form="settings" data-id="${a.id}" style="margin-top:10px"><label>Instrument</label><select name="instrument">${S.cfg.instruments.map(i => `<option ${i === a.instrument ? 'selected' : ''}>${esc(i)}</option>`).join('')}</select>${riskFields(a.settings)}<div class="err"></div><button class="btn pri">Save and apply</button></form></details></div>`).join('')}
    ${accounts.length < 1 || true ? `<div class="card"><h3>Add MT5 account</h3><p class="sm" style="margin-bottom:6px">Use the trading (master) password. We recommend testing on a demo account first. Your password is encrypted and never shown to administrators.</p>
      <form data-form="add-mt5"><div class="frow"><div><label>MT5 login</label><input name="login" inputmode="numeric" required></div><div><label>Broker server</label><input name="server" placeholder="e.g. Exness-MT5Real" required></div>
      <div><label>Broker name (optional)</label><input name="broker"></div><div><label>MT5 password</label><input name="password" type="password" autocomplete="off" required></div><div><label>Instrument</label><select name="instrument">${instr}</select></div></div>
      <h3 style="margin-top:18px">Risk settings</h3>${riskFields()}<div class="err"></div><button class="btn pri">Add account</button></form></div>` : ''}</div>`;
  };

  // ---------- hosting ----------
  pages.hosting = async () => {
    const { deployments } = await api('/hosting');
    return `<div class="wrap page fade"><div class="ph"><div><h2>Hosting management</h2><p class="sm">Your isolated MT5 terminal on ALGOEA cloud VPS infrastructure.</p></div></div>
    ${deployments.length ? deployments.map(d => `<div class="card" style="margin-bottom:16px"><div class="ph" style="margin-bottom:8px"><h3>Terminal for ${esc(d.login)} · ${esc(d.instrument)}</h3><div>${statusPill(d.status)}</div></div>
      <div class="grid g2"><dl class="kv"><dt>MT5 connection</dt><dd>${d.terminal_connected ? pill('Connected', 'ok') : pill('Disconnected', 'bad')}</dd><dt>Auto trading</dt><dd>${d.autotrading ? 'Enabled' : 'Disabled'}</dd><dt>EA version</dt><dd>${esc(d.ea_version || '–')}</dd><dt>Last report</dt><dd>${ago(d.last_report_at)}</dd>${d.last_error ? `<dt>Last error</dt><dd class="neg">${esc(d.last_error)}</dd>` : ''}</dl>
      <dl class="kv"><dt>VPS</dt><dd>${d.vps ? esc(d.vps.name) + ' ' + pill(d.vps.status === 'online' ? 'Online' : 'Offline', d.vps.status === 'online' ? 'ok' : 'bad') : 'Not assigned'}</dd><dt>Region</dt><dd>${esc(d.vps?.region || '–')}</dd><dt>CPU</dt><dd>${d.vps?.cpu_pct != null ? num(d.vps.cpu_pct, 0) + '%' : '–'}</dd><dt>RAM</dt><dd>${d.vps?.ram_pct != null ? num(d.vps.ram_pct, 0) + '%' : '–'}</dd><dt>Heartbeat</dt><dd>${ago(d.vps?.last_seen)}</dd></dl></div>
      <div class="ctl" style="margin:14px 0"><button class="btn pri sm" data-act="ea" data-id="${d.id}" data-a="start">Start</button><button class="btn dng sm" data-act="ea" data-id="${d.id}" data-a="stop">Stop</button><button class="btn sm" data-act="ea" data-id="${d.id}" data-a="restart">Restart</button><button class="btn sm" data-act="ea" data-id="${d.id}" data-a="enable_autotrading">Enable auto trading</button></div>
      <h3>EA error logs</h3><div class="log">${d.logs.length ? d.logs.map(l => `<div class="${esc(l.level)}">${dt(l.ts)} [${esc(l.level)}] ${esc(l.message)}</div>`).join('') : 'No log entries yet.'}</div></div>`).join('')
      : `<div class="card center"><h3>No terminal yet</h3><p style="margin:8px 0 14px">Add an MT5 account and deploy IRON SCALPING to get your hosted terminal.</p><a class="btn pri" href="#/mt5">Go to MT5 accounts</a></div>`}
    <p class="sm">Each customer's terminal runs in its own isolated folder. You cannot access, and others cannot access, any other customer's terminal or data.</p></div>`;
  };

  // ---------- support ----------
  pages.support = async (q) => {
    const faq = `<div class="card" style="margin-bottom:16px"><h3>Frequently asked questions</h3>${faqs.map(f => `<details><summary>${f[0]}</summary><p>${f[1]}</p></details>`).join('')}</div>`;
    if (!S.me) return `<div class="wrap page fade" style="max-width:820px"><h2>Support</h2><p style="margin-bottom:18px">Log in to open a support request.</p>${faq}<a class="btn pri" href="#/login">Log in</a></div>`;
    const { tickets } = await api('/support');
    let detail = '';
    if (q.get('t')) {
      const t = await api('/support/' + encodeURIComponent(q.get('t')));
      detail = `<div class="card" style="margin-bottom:16px"><h3>${esc(t.ticket.subject)} ${pill(t.ticket.status, t.ticket.status === 'closed' ? 'warn' : 'ok')}</h3>${t.messages.map(m => `<div style="padding:10px 0;border-bottom:1px solid var(--line)"><b class="${m.is_staff ? 'g' : ''}">${m.is_staff ? 'ALGOEA Support' : 'You'}</b> <span class="sm mut">${dt(m.created_at)}</span><div style="white-space:pre-wrap">${esc(m.body)}</div></div>`).join('')}
        <form data-form="reply" data-id="${t.ticket.id}"><label>Reply</label><textarea name="message" rows="3" required></textarea><div class="err"></div><button class="btn pri">Send reply</button></form></div>`;
    }
    return `<div class="wrap page fade"><div class="ph"><h2>Support</h2></div>${detail}<div class="grid g2"><div class="card"><h3>New request</h3><form data-form="ticket"><label>Subject</label><input name="subject" required><label>Message</label><textarea name="message" rows="5" required></textarea><div class="err"></div><button class="btn pri">Submit</button></form></div>
      <div class="card"><h3>Your requests</h3>${tickets.length ? tickets.map(t => `<a href="#/support?t=${t.id}" style="display:block;padding:10px 0;border-bottom:1px solid var(--line);color:var(--tx)"><b>${esc(t.subject)}</b> ${pill(t.status, t.status === 'closed' ? 'warn' : 'ok')}<div class="sm mut">${dt(t.updated_at)}</div></a>`).join('') : '<div class="empty">No requests yet.</div>'}</div></div><div style="margin-top:16px">${faq}</div></div>`;
  };

  // ---------- admin ----------
  let adminTab = 'overview';
  const ADMIN_TABS = [['overview', 'Overview'], ['users', 'Customers'], ['payments', 'Payments'], ['mt5', 'MT5 accounts'], ['vps', 'VPS'], ['strategy', 'IRON SCALPING'], ['settings', 'Settings'], ['tickets', 'Support'], ['logs', 'Logs']];
  const tbl = (head, rows) => rows.length ? `<div class="tw"><table><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</table></div>` : '<div class="empty">Nothing here yet.</div>';
  async function adminBody() {
    switch (adminTab) {
      case 'overview': {
        const o = await api('/admin/overview'); const c = (l, v) => `<div class="card stat"><div class="l">${l}</div><div class="v">${v}</div></div>`;
        return `<div class="grid g4">${c('Customers', o.customers)}${c('Active subscriptions', o.active_subscriptions)}${c('Expired', o.expired_subscriptions)}${c('Revenue (30d)', money(o.revenue_cents_30d / 100))}${c('MT5 accounts', o.mt5_accounts)}${c('EAs running', o.deployments_running)}${c('EAs in error', o.deployments_error)}${c('VPS online', o.vps_online + ' / ' + o.vps_total)}${c('Open tickets', o.open_tickets)}</div>`;
      }
      case 'users': {
        const { users } = await api('/admin/users');
        return tbl(['Customer', 'Verified', 'Status', 'Subscription', 'Expires', 'MT5', 'Actions'], users.map(u => [`<b>${esc(u.name)}</b><div class="sm mut">${esc(u.email)}</div>`, u.email_verified ? '✓' : '–', pill(u.status, u.status === 'active' ? 'ok' : 'bad'),
          pill(u.sub_status || 'none', u.sub_status === 'active' ? 'ok' : 'warn'), dd(u.ends_at), u.mt5_count,
          `<div class="ctl"><button class="btn sm" data-act="a-activate" data-id="${u.id}">Verify payment</button><button class="btn sm" data-act="a-revoke" data-id="${u.id}">Revoke licence</button><button class="btn sm ${u.status === 'active' ? 'dng' : ''}" data-act="a-status" data-id="${u.id}" data-s="${u.status === 'active' ? 'suspended' : 'active'}">${u.status === 'active' ? 'Suspend' : 'Activate'}</button></div>`]));
      }
      case 'payments': {
        const { payments } = await api('/admin/payments');
        return tbl(['Date', 'Customer', 'Amount', 'Method', 'Reference', 'Status'], payments.map(p => [dt(p.created_at), esc(p.email), money(p.amount_cents / 100, p.currency), esc(p.provider), esc(p.provider_ref || '–'), pill(p.status, p.status === 'complete' ? 'ok' : p.status === 'pending' ? 'warn' : 'bad')]));
      }
      case 'mt5': {
        const { accounts } = await api('/admin/mt5');
        return `<p class="sm mut" style="margin-bottom:10px">Passwords are encrypted and are never available to administrators.</p>` + tbl(['Customer', 'Login', 'Server', 'Status', 'EA', 'VPS', 'Balance', 'Equity', 'Last report', 'Control'], accounts.map(a => [esc(a.email), esc(a.login), esc(a.server), esc(a.status), a.ea_status ? statusPill(a.ea_status) : '–', esc(a.vps_name || '–'), a.balance == null ? '–' : num(a.balance), a.equity == null ? '–' : num(a.equity), ago(a.last_report_at),
          a.deployment_id ? `<div class="ctl"><button class="btn sm" data-act="a-ea" data-id="${a.deployment_id}" data-a="restart">Restart</button><button class="btn sm dng" data-act="a-ea" data-id="${a.deployment_id}" data-a="stop">Stop</button></div>` : '–']));
      }
      case 'vps': {
        const { vps } = await api('/admin/vps');
        return `<div class="ctl" style="margin-bottom:14px"><button class="btn pri" data-act="a-vps-new">Register new VPS</button></div>` + tbl(['Name', 'Region', 'Status', 'Terminals', 'CPU', 'RAM', 'Heartbeat', 'Agent', 'Actions'], vps.map(v => [`<b>${esc(v.name)}</b><div class="sm mut">${esc(v.hostname || '')}</div>`, esc(v.region || '–'), pill(v.status, v.status === 'online' ? 'ok' : v.status === 'disabled' ? 'warn' : 'bad'), v.deployments + ' / ' + v.capacity, v.cpu_pct == null ? '–' : num(v.cpu_pct, 0) + '%', v.ram_pct == null ? '–' : num(v.ram_pct, 0) + '%', ago(v.last_seen), esc(v.agent_version || '–'),
          `<div class="ctl"><button class="btn sm" data-act="a-vps-key" data-id="${v.id}">Rotate key</button><button class="btn sm" data-act="a-vps-toggle" data-id="${v.id}" data-s="${v.status === 'disabled' ? 'offline' : 'disabled'}">${v.status === 'disabled' ? 'Enable' : 'Disable'}</button></div>`]));
      }
      case 'strategy': {
        const { settings: s } = await api('/admin/strategy');
        const f = (k, l, h) => `<div><label>${l}</label><input name="${k}" value="${esc(s[k])}">${h ? `<div class="hint">${h}</div>` : ''}</div>`;
        return `<div class="card"><h3>ALGOEA IRON SCALPING</h3><form data-form="a-strategy"><div class="frow">${f('ea_version', 'EA version', 'x.y.z, deployed to terminals')}<div><label>Deployments enabled</label><select name="ea_enabled"><option value="1" ${s.ea_enabled === '1' ? 'selected' : ''}>Enabled</option><option value="0" ${s.ea_enabled === '0' ? 'selected' : ''}>Disabled (stops all EAs)</option></select></div>
          ${f('allowed_instruments', 'Allowed instruments', 'Comma separated')}${f('cap_risk_percent', 'Cap: risk per trade %')}${f('cap_fixed_lot', 'Cap: fixed lot')}${f('cap_daily_loss_pct', 'Cap: daily loss %')}${f('cap_drawdown_pct', 'Cap: drawdown %')}${f('cap_max_spread_points', 'Cap: spread points')}${f('cap_max_open_trades', 'Cap: open trades')}</div>
          <div class="chk"><input type="checkbox" name="push_config" id="pc"><label for="pc">Re-apply configuration to all deployed terminals (clamps customer settings to the new caps)</label></div><div class="err"></div><button class="btn pri">Save strategy settings</button></form></div>`;
      }
      case 'settings': {
        const { settings: s } = await api('/admin/settings');
        const f = (k, l, h) => `<div><label>${l}</label><input name="${k}" value="${esc(s[k])}">${h ? `<div class="hint">${h}</div>` : ''}</div>`;
        return `<div class="card"><h3>Platform settings</h3><form data-form="a-settings"><div class="frow">${f('price_cents', 'Monthly price (cents)', '30000 = R300.00. Must match PayFast.')}${f('max_mt5_accounts', 'Max MT5 accounts per customer')}${f('tz_offset_minutes', 'Reporting timezone offset (min)', '120 = South Africa')}<div><label>Registration</label><select name="signups_open"><option value="1" ${s.signups_open === '1' ? 'selected' : ''}>Open</option><option value="0" ${s.signups_open === '0' ? 'selected' : ''}>Closed</option></select></div></div><div class="err"></div><button class="btn pri">Save settings</button></form></div>`;
      }
      case 'tickets': {
        const { tickets } = await api('/admin/tickets');
        let det = '';
        if (adminTicket) {
          const t = await api('/admin/tickets/' + adminTicket);
          det = `<div class="card" style="margin-bottom:16px"><h3>${esc(t.ticket.subject)} <span class="sm mut">${esc(t.ticket.email)}</span></h3>${t.messages.map(m => `<div style="padding:8px 0;border-bottom:1px solid var(--line)"><b class="${m.is_staff ? 'g' : ''}">${m.is_staff ? 'Staff' : 'Customer'}</b> <span class="sm mut">${dt(m.created_at)}</span><div style="white-space:pre-wrap">${esc(m.body)}</div></div>`).join('')}
            <form data-form="a-reply" data-id="${t.ticket.id}"><textarea name="message" rows="3" required></textarea><div class="chk"><input type="checkbox" name="close" id="cl"><label for="cl">Close ticket</label></div><div class="err"></div><button class="btn pri">Reply</button></form></div>`;
        }
        return det + tbl(['#', 'Subject', 'Customer', 'Status', 'Updated', ''], tickets.map(t => [t.id, esc(t.subject), esc(t.email), pill(t.status, t.status === 'open' ? 'warn' : 'ok'), dt(t.updated_at), `<button class="btn sm" data-act="a-ticket" data-id="${t.id}">Open</button>`]));
      }
      case 'logs': {
        const { logs } = await api('/admin/logs?type=' + adminLogType);
        const head = adminLogType === 'audit' ? ['Time', 'User', 'Action', 'Target', 'IP'] : adminLogType === 'ea' ? ['Time', 'Deployment', 'Level', 'Message'] : ['Time', 'Level', 'Source', 'Message'];
        const rows = logs.map(l => adminLogType === 'audit' ? [dt(l.ts), esc(l.email || '–'), esc(l.action), esc(l.target || ''), esc(l.ip || '')] : adminLogType === 'ea' ? [dt(l.ts), l.deployment_id, esc(l.level), esc(l.message)] : [dt(l.ts), esc(l.level), esc(l.source), esc(l.message)]);
        return `<div class="tabs">${[['system', 'System'], ['audit', 'Audit'], ['ea', 'EA errors']].map(([k, l]) => `<button data-act="a-logtype" data-k="${k}" class="${adminLogType === k ? 'on' : ''}">${l}</button>`).join('')}</div>` + tbl(head, rows);
      }
    }
  }
  let adminLogType = 'system', adminTicket = null;
  pages.admin = async () => {
    if (!S.me.is_admin) return '<div class="wrap page"><div class="card center"><h3>Administrator access required</h3></div></div>';
    return `<div class="wrap page fade"><div class="ph"><h2>Administrator</h2></div><div class="tabs">${ADMIN_TABS.map(([k, l]) => `<button data-act="a-tab" data-k="${k}" class="${adminTab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="adminBody">${await adminBody()}</div></div>`;
  };
  async function reloadAdmin() { try { $('#adminBody').innerHTML = await adminBody(); $$('[data-act=a-tab]').forEach(b => b.classList.toggle('on', b.dataset.k === adminTab)); } catch (e) { toast(e.message, true); } }
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  // ---------- router ----------
  function parseHash() { const h = location.hash.replace(/^#\/?/, ''); const [p, qs] = h.split('?'); return { page: p || 'home', q: new URLSearchParams(qs || '') }; }
  const GUEST_ONLY = ['login', 'register', 'forgot', 'reset'];
  const AUTH_ONLY = ['dashboard', 'hosting', 'mt5', 'account', 'admin'];
  let renderToken = 0;
  async function render() {
    const tk = ++renderToken;
    let { page, q } = parseHash();
    if (!pages[page]) page = 'home';
    if (S.me && GUEST_ONLY.includes(page)) { location.hash = '#/dashboard'; return; }
    if (!S.me && AUTH_ONLY.includes(page)) { location.hash = '#/login'; return; }
    renderShell(page);
    const app = $('#app');
    app.innerHTML = '<div class="wrap page"><p class="mut">Loading…</p></div>';
    try {
      const html = await pages[page](q);
      if (tk !== renderToken) return;
      app.innerHTML = html; window.scrollTo(0, 0);
    } catch (e) {
      if (e.status === 401) { S.me = null; location.hash = '#/login'; return; }
      app.innerHTML = `<div class="wrap page"><div class="card center"><h3>Something went wrong</h3><p>${esc(e.message)}</p></div></div>`;
    }
  }
  async function loadMe() { try { const j = await api('/me'); S.me = j.user; S.unread = j.unread; } catch { S.me = null; } }
  function connectWs() {
    if (S.ws || !S.me) return;
    try {
      const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
      S.ws = ws; let t;
      ws.onmessage = () => { clearTimeout(t); t = setTimeout(() => { const p = parseHash().page; if (['dashboard', 'hosting'].includes(p) && !document.hidden) render(); }, 1500); };
      ws.onclose = () => { S.ws = null; if (S.me) setTimeout(connectWs, 5000); };
    } catch { /* */ }
  }

  // ---------- actions ----------
  const act = {
    burger: () => $('#nav').classList.toggle('open'),
    logout: async () => { await api('/auth/logout', { method: 'POST', body: {} }); S.me = null; if (S.ws) S.ws.close(); location.hash = '#/home'; render(); },
    'logout-all': async () => { if (!confirm('Log out from all devices?')) return; await api('/auth/logout-all', { method: 'POST', body: {} }); S.me = null; location.hash = '#/login'; render(); },
    checkout: async () => {
      try {
        const c = await api('/billing/checkout', { method: 'POST', body: {} });
        const f = document.createElement('form'); f.method = 'POST'; f.action = c.action;
        for (const [k, v] of Object.entries(c.fields)) { const i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); }
        document.body.appendChild(f); f.submit();
      } catch (e) { toast(e.message, true); }
    },
    'cancel-renew': async () => { if (!confirm('Cancel automatic renewal?')) return; try { const r = await api('/billing/cancel', { method: 'POST', body: {} }); toast(r.message); render(); } catch (e) { toast(e.message, true); } },
    ea: async (el) => { try { const r = await api(`/deployments/${el.dataset.id}/command`, { method: 'POST', body: { action: el.dataset.a } }); toast(r.message); } catch (e) { toast(e.message, true); } },
    deploy: async (el) => { el.disabled = true; try { await api(`/mt5/${el.dataset.id}/deploy`, { method: 'POST', body: {} }); toast('Deployment queued. Your terminal is being prepared.'); render(); } catch (e) { toast(e.message, true); el.disabled = false; } },
    'rm-acct': async (el) => { if (!confirm('Remove this MT5 account and delete its stored credentials? The hosted terminal will be removed.')) return; try { await api('/mt5/' + el.dataset.id, { method: 'DELETE' }); toast('Account removed'); render(); } catch (e) { toast(e.message, true); } },
    perf: (el) => { dashState.perf = el.dataset.k; $('#perfChart').innerHTML = perfChart(dashState.data); $$('#perfTabs button').forEach(b => b.classList.toggle('on', b === el)); },
    'a-tab': (el) => { adminTab = el.dataset.k; adminTicket = null; reloadAdmin(); },
    'a-logtype': (el) => { adminLogType = el.dataset.k; reloadAdmin(); },
    'a-ticket': (el) => { adminTicket = el.dataset.id; reloadAdmin(); },
    'a-activate': async (el) => { const reference = prompt('Payment reference you verified (e.g. EFT reference):'); if (!reference) return; const months = prompt('Months to activate (1-12):', '1'); if (!months) return; try { await api(`/admin/users/${el.dataset.id}/activate`, { method: 'POST', body: { months: Number(months), reference } }); toast('Subscription activated'); reloadAdmin(); } catch (e) { toast(e.message, true); } },
    'a-revoke': async (el) => { if (!confirm('Revoke this licence and stop their EAs?')) return; try { await api(`/admin/users/${el.dataset.id}/revoke`, { method: 'POST', body: {} }); toast('Licence revoked'); reloadAdmin(); } catch (e) { toast(e.message, true); } },
    'a-status': async (el) => { try { await api(`/admin/users/${el.dataset.id}/status`, { method: 'POST', body: { status: el.dataset.s } }); toast('Updated'); reloadAdmin(); } catch (e) { toast(e.message, true); } },
    'a-ea': async (el) => { try { await api(`/admin/deployments/${el.dataset.id}/command`, { method: 'POST', body: { action: el.dataset.a } }); toast('Command queued'); } catch (e) { toast(e.message, true); } },
    'a-vps-new': async () => { const name = prompt('VPS name (e.g. za-vps-01):'); if (!name) return; const region = prompt('Region (optional):') || ''; const capacity = prompt('Max terminals on this VPS:', '20'); try { const r = await api('/admin/vps', { method: 'POST', body: { name, region, capacity: Number(capacity) } }); prompt('Copy this agent API key now. It is shown only once:', r.api_key); reloadAdmin(); } catch (e) { toast(e.message, true); } },
    'a-vps-key': async (el) => { if (!confirm('Rotate the key? The agent stops working until updated.')) return; try { const r = await api(`/admin/vps/${el.dataset.id}/rotate-key`, { method: 'POST', body: {} }); prompt('New agent API key (shown once):', r.api_key); } catch (e) { toast(e.message, true); } },
    'a-vps-toggle': async (el) => { try { await api('/admin/vps/' + el.dataset.id, { method: 'POST', body: { status: el.dataset.s } }); reloadAdmin(); } catch (e) { toast(e.message, true); } }
  };
  document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (el && act[el.dataset.act]) { e.preventDefault(); act[el.dataset.act](el); } });
  document.addEventListener('change', e => { if (e.target.id === 'acctSel') { dashState.account = e.target.value; render(); } });
  const forms = {
    login: async f => { const r = await api('/auth/login', { method: 'POST', body: formData(f) }); S.me = r.user; await loadMe(); connectWs(); location.hash = '#/dashboard'; render(); },
    register: async f => { const r = await api('/auth/register', { method: 'POST', body: formData(f) }); f.outerHTML = `<p class="g" style="margin:14px 0">${esc(r.message)} Check your inbox, then <a href="#/login">log in</a>.</p>`; },
    forgot: async f => { const r = await api('/auth/forgot', { method: 'POST', body: formData(f) }); f.outerHTML = `<p class="g" style="margin:14px 0">${esc(r.message)}</p>`; },
    reset: async f => { await api('/auth/reset', { method: 'POST', body: formData(f) }); toast('Password updated. Please log in.'); location.hash = '#/login'; },
    profile: async f => { await api('/me', { method: 'PUT', body: formData(f) }); await loadMe(); toast('Profile saved'); },
    password: async f => { await api('/me/password', { method: 'POST', body: formData(f) }); f.reset(); toast('Password changed. Other devices were logged out.'); },
    'add-mt5': async f => { const o = formData(f); const body = { login: o.login, server: o.server, broker: o.broker || undefined, password: o.password, instrument: o.instrument, settings: settingsFrom(f) }; await api('/mt5', { method: 'POST', body }); toast('MT5 account added. Deploy IRON SCALPING when ready.'); render(); },
    settings: async f => { const o = formData(f); await api(`/mt5/${f.dataset.id}/settings`, { method: 'PUT', body: { instrument: o.instrument, settings: settingsFrom(f) } }); toast('Settings saved and queued for your terminal'); },
    ticket: async f => { const r = await api('/support', { method: 'POST', body: formData(f) }); toast('Request submitted'); location.hash = '#/support?t=' + r.id; render(); },
    reply: async f => { await api(`/support/${f.dataset.id}/reply`, { method: 'POST', body: formData(f) }); toast('Reply sent'); render(); },
    'a-strategy': async f => { const o = formData(f); const push = o.push_config; delete o.push_config; await api('/admin/strategy', { method: 'PUT', body: { settings: o, push_config: push } }); toast('Strategy settings saved'); },
    'a-settings': async f => { await api('/admin/settings', { method: 'PUT', body: { settings: formData(f) } }); toast('Settings saved'); S.cfg = await api('/config'); },
    'a-reply': async f => { const o = formData(f); await api(`/admin/tickets/${f.dataset.id}/reply`, { method: 'POST', body: { message: o.message, close: o.close } }); toast('Reply sent'); reloadAdmin(); }
  };
  document.addEventListener('submit', async e => {
    const f = e.target.closest('[data-form]'); if (!f) return; e.preventDefault();
    const err = f.querySelector('.err'); if (err) err.textContent = '';
    const btn = f.querySelector('button:not([type=button])'); if (btn) btn.disabled = true;
    try { await forms[f.dataset.form](f); } catch (x) { if (err) err.textContent = x.message; else toast(x.message, true); }
    if (btn) btn.disabled = false;
  });
  window.addEventListener('hashchange', render);
  (async () => { await Promise.all([loadMe(), api('/config').then(c => S.cfg = c)]); connectWs(); render(); })();
})();
