# ALGOEA – Forex EA Hosting Platform

Full-stack platform: website + API + admin panel + MT5 VPS agent + the ALGOEA IRON SCALPING EA.
Backend has **zero npm dependencies** (Node 22.5+ built-in SQLite).

## What is in this folder
| Path | Purpose |
|---|---|
| `server.js`, `lib/` | REST API, WebSocket push, auth, billing (PayFast), MT5/VPS management, admin, agent API |
| `public/` | Website (14 pages, dashboards, charts, admin panel). Responsive, installable on phones |
| `ea/ALGOEA_IronScalping.mq5` | The built-in strategy (MetaTrader 5 source) |
| `agent/algoea_agent.py` | Windows VPS agent: installs isolated terminals, deploys the EA, restarts crashed terminals, reports real MT5 data |
| `test/` | `npm test` (61 end-to-end checks), plus page render checks |

## Credentials you must supply (nothing works in production without these)
Put them in `.env` (copy `.env.example`) or your host's environment settings.

| Variable | Needed for | Where to get it |
|---|---|---|
| `MASTER_KEY` | Encrypting MT5 passwords. **Back it up. If lost, stored MT5 passwords are unrecoverable.** | `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"` |
| `APP_URL` | Links in emails, PayFast callbacks (must be public `https://`) | Your domain |
| `RESEND_API_KEY`, `MAIL_FROM` | Email verification and password reset | resend.com (verify your sending domain) |
| `PAYFAST_MERCHANT_ID`, `PAYFAST_MERCHANT_KEY`, `PAYFAST_PASSPHRASE`, `PAYFAST_SANDBOX` | R300/month recurring payments | payfast.co.za (use sandbox first). Set the passphrase in PayFast settings too |
| VPS agent key (one per VPS) | Agent to API authentication | Admin panel > VPS > Register new VPS |

Without PayFast keys the site still works; the admin can activate a customer from **Admin > Customers > Verify payment** after confirming an EFT.

## Admin access
Only `katseatang1@gmail.com` (set by `ADMIN_EMAIL`) can ever be administrator. Register that address on the site and click the verification link; admin rights are granted at verification. No other account can become admin, and the API ignores any role sent at registration.

## Run locally
```
cp .env.example .env     # fill in values
npm start                # http://localhost:3000
npm test
```
Without `RESEND_API_KEY`, verification/reset links are printed in the server console (development only).

## Deploy the website (cloud)
Any host that runs Node 22 or Docker and offers a **persistent disk** works (Render, Railway, Fly.io, a VPS). Mount the disk at `/data` (the Dockerfile sets `DATA_DIR=/data`), set the environment variables above, and put it behind HTTPS. Back up `/data/algoea.db` and `MASTER_KEY`.
SQLite is right for a first few hundred customers on one server. To scale beyond that, move `lib/db.js` to PostgreSQL (the schema is plain SQL).

## Set up a Windows VPS (hosts customer MT5 terminals)
1. Windows Server VPS, Python 3.10+, `pip install MetaTrader5`.
2. Download the MT5 installer (`mt5setup.exe`) from MetaQuotes. The agent installs it silently the first time.
3. Compile `ea/ALGOEA_IronScalping.mq5` in MetaEditor (F7) and copy the resulting `.ex5` next to the agent.
4. Copy `agent/` to the VPS, copy `agent_config.example.json` to `agent_config.json`, fill in `api_url` and the VPS key from the admin panel.
5. Run `python algoea_agent.py` (use Task Scheduler or NSSM to start at boot).

How a deploy works: customer taps Deploy → API assigns the least-loaded online VPS → agent copies a portable MT5 into its own folder, installs the EA, writes `algoea_config.ini`, logs in with the customer's credentials, opens an XAUUSD M5 chart with the EA. The agent then reads balance, equity, positions and closed trades **from the terminal** and posts them to the API. The startup file containing the password is deleted ~45 seconds after launch; later restarts reuse MT5's own saved login.

## Security design
- Passwords: scrypt. Sessions: random tokens, HttpOnly + SameSite=Strict cookies, "log out everywhere".
- MT5 passwords: AES-256-GCM at rest. No API returns them. Only the owning VPS agent receives them, over HTTPS, at deploy time.
- Customers only ever query rows filtered by their own user id. Agents can only touch deployments assigned to their own VPS.
- Rate limits on login/registration/reset; CSRF origin checks; CSP and security headers; audit log of sensitive actions.
- Risk caps are enforced twice: in the API (admin-set caps) and compiled into the EA.

## Honest status – read before taking real money
- The EA source has **not been compiled or backtested** here (no MetaTrader in this environment). Compile it, fix any compiler messages, backtest, and run on a demo account for weeks before any live use. No strategy can promise profit.
- The agent is written for Windows and was **not run against a live MT5 terminal** here. The server side of the agent protocol is covered by the automated tests; expect some adjustment when you first run it on a real VPS.
- PayFast was tested for signature generation and forged-notification rejection only. Test the full flow in the PayFast sandbox before going live.
- For true isolation on a shared VPS, run each customer terminal under its own Windows user (the agent restricts folder ACLs, but separate OS users are stronger).
- Terms and Privacy pages are templates. Have a South African attorney review them. Holding other people's broker logins and running trading software for them may carry regulatory obligations (e.g. FSCA/FAIS); take legal advice before launch.
- Email, PayFast and VPS agents need the credentials above before these parts work for real.
