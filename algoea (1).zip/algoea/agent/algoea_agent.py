"""
ALGOEA VPS Agent (Windows)

Runs on each Windows VPS. It:
  * sends heartbeats (CPU/RAM + terminal states) to the ALGOEA API
  * installs an isolated portable MT5 terminal per customer deployment
  * deploys the compiled ALGOEA_IronScalping.ex5 and writes its config
  * starts / stops / restarts terminals and restarts them after unexpected shutdown
  * reads REAL account, position and trade data from MT5 and reports it

Requirements (on the VPS):  Python 3.10+,  pip install MetaTrader5
Configuration: agent_config.json next to this file (see README.md).
Nothing here simulates data: if MT5 is unavailable, nothing is reported.
"""
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timedelta

VERSION = "1.0.0"
HERE = os.path.dirname(os.path.abspath(__file__))


def load_config():
    with open(os.path.join(HERE, "agent_config.json"), encoding="utf-8") as f:
        c = json.load(f)
    c.setdefault("poll_seconds", 30)
    c.setdefault("base_dir", r"C:\ALGOEA")
    c.setdefault("template_dir", os.path.join(c["base_dir"], "mt5_template"))
    c.setdefault("mt5_install_dir", r"C:\Program Files\MetaTrader 5")
    c.setdefault("mt5_setup_exe", "")
    c.setdefault("ea_ex5", os.path.join(HERE, "ALGOEA_IronScalping.ex5"))
    return c


CFG = None
try:
    import MetaTrader5 as mt5  # type: ignore
except Exception:  # pragma: no cover
    mt5 = None


def log(msg):
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg, flush=True)


# ---------------------------------------------------------------- API
def api(path, body=None, timeout=25):
    data = json.dumps(body or {}).encode()
    req = urllib.request.Request(
        CFG["api_url"].rstrip("/") + path, data=data, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + CFG["api_key"]})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def safe_api(path, body=None):
    try:
        return api(path, body)
    except Exception as e:  # network / server problems must never crash the agent
        log(f"API error {path}: {e}")
        return None


# ---------------------------------------------------------------- system
def ram_pct():
    class MS(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("a", ctypes.c_ulonglong),
                    ("b", ctypes.c_ulonglong), ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong),
                    ("e", ctypes.c_ulonglong), ("f", ctypes.c_ulonglong), ("g", ctypes.c_ulonglong)]
    m = MS(); m.dwLength = ctypes.sizeof(MS)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return float(m.dwMemoryLoad)


def ps(cmd, timeout=30):
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                       capture_output=True, text=True, timeout=timeout)
    return r.stdout.strip()


def cpu_pct():
    try:
        return float(ps("(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average"))
    except Exception:
        return None


def running_terminals():
    out = ps("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | ForEach-Object { $_.ExecutablePath }")
    return {p.strip().lower() for p in out.splitlines() if p.strip()}


# ---------------------------------------------------------------- terminals
def tdir(dep_id):
    return os.path.join(CFG["base_dir"], "terminals", f"dep_{dep_id}")


def texe(dep_id):
    return os.path.join(tdir(dep_id), "terminal64.exe")


def state_path():
    return os.path.join(CFG["base_dir"], "state.json")


def load_state():
    try:
        with open(state_path(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(s):
    os.makedirs(CFG["base_dir"], exist_ok=True)
    with open(state_path(), "w", encoding="utf-8") as f:
        json.dump(s, f)


def ensure_template():
    """Automatic terminal installation: build a portable MT5 template once per VPS."""
    t = CFG["template_dir"]
    if os.path.exists(os.path.join(t, "terminal64.exe")):
        return
    inst = CFG["mt5_install_dir"]
    if not os.path.exists(os.path.join(inst, "terminal64.exe")):
        setup = CFG.get("mt5_setup_exe")
        if not setup or not os.path.exists(setup):
            raise RuntimeError("MT5 is not installed and mt5_setup_exe is not configured")
        log("Installing MetaTrader 5 (silent)...")
        subprocess.run([setup, "/auto"], timeout=900)
        for _ in range(60):
            if os.path.exists(os.path.join(inst, "terminal64.exe")):
                break
            time.sleep(5)
    if not os.path.exists(os.path.join(inst, "terminal64.exe")):
        raise RuntimeError("MT5 installation did not complete")
    log("Creating portable MT5 template")
    shutil.copytree(inst, t, dirs_exist_ok=True)


def restrict_acl(path):
    """Limit the terminal folder to SYSTEM + Administrators (customers never get shell access)."""
    try:
        subprocess.run(["icacls", path, "/inheritance:r", "/grant:r", "SYSTEM:(OI)(CI)F", "Administrators:(OI)(CI)F"],
                       capture_output=True, timeout=60)
    except Exception as e:
        log(f"ACL warning: {e}")


def write_config(dep_id, cfg):
    s = cfg["settings"]
    files = os.path.join(tdir(dep_id), "MQL5", "Files")
    os.makedirs(files, exist_ok=True)
    lines = {"enabled": 1 if cfg.get("enabled", True) else 0, "instrument": cfg["instrument"]}
    for k, v in s.items():
        lines[k] = (1 if v else 0) if isinstance(v, bool) else v
    with open(os.path.join(files, "algoea_config.ini"), "w", encoding="ascii") as f:
        f.write("\n".join(f"{k}={v}" for k, v in lines.items()) + "\n")


def resolve_symbol(instrument):
    """Brokers often add suffixes (XAUUSDm, XAUUSD.a). Find the real symbol on the connected terminal."""
    syms = mt5.symbols_get() or []
    names = [x.name for x in syms]
    if instrument in names:
        return instrument
    c = sorted([n for n in names if n.upper().startswith(instrument.upper())], key=len)
    return c[0] if c else instrument


def launch(dep_id, account, instrument, symbol=None):
    d = tdir(dep_id)
    ini = os.path.join(d, "config", "algoea_startup.ini")
    os.makedirs(os.path.dirname(ini), exist_ok=True)
    with open(ini, "w", encoding="ascii") as f:
        f.write(f"[Common]\nLogin={account['login']}\nPassword={account['password']}\nServer={account['server']}\n"
                f"KeepPrivate=1\nNewsEnable=0\n[Experts]\nAllowLiveTrading=1\nAllowDllImport=0\nEnabled=1\n"
                f"[StartUp]\nExpert=ALGOEA_IronScalping\nSymbol={symbol or instrument}\nPeriod=M5\n")
    subprocess.Popen([texe(dep_id), "/portable", f"/config:{ini}"], cwd=d,
                     creationflags=0x00000008 | 0x00000200)  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP

    # The terminal keeps its own encrypted login after first start; do not leave the password on disk.
    def scrub():
        time.sleep(45)
        try:
            with open(ini, "w") as f:
                f.write("")
            os.remove(ini)
        except Exception:
            pass
    import threading
    threading.Thread(target=scrub, daemon=True).start()


def relaunch(dep_id, instrument, symbol=None):
    """Start the terminal without credentials. After the first login MT5 keeps its own saved login,
    so automatic restarts never need the customer's password."""
    d = tdir(dep_id)
    ini = os.path.join(d, "config", "algoea_restart.ini")
    os.makedirs(os.path.dirname(ini), exist_ok=True)
    with open(ini, "w", encoding="ascii") as f:
        f.write(f"[Common]\nKeepPrivate=1\nNewsEnable=0\n[Experts]\nAllowLiveTrading=1\nAllowDllImport=0\nEnabled=1\n"
                f"[StartUp]\nExpert=ALGOEA_IronScalping\nSymbol={symbol or instrument}\nPeriod=M5\n")
    subprocess.Popen([texe(dep_id), "/portable", f"/config:{ini}"], cwd=d,
                     creationflags=0x00000008 | 0x00000200)


def kill(dep_id):
    p = texe(dep_id).replace("'", "''")
    ps(f"Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | Where-Object {{ $_.ExecutablePath -eq '{p}' }} | ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force }}")


def read_status(dep_id):
    p = os.path.join(tdir(dep_id), "MQL5", "Files", "algoea_status.txt")
    out = {}
    try:
        with open(p, encoding="ascii", errors="ignore") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    out[k] = v
        out["_age"] = time.time() - os.path.getmtime(p)
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- MT5 data
def mt5_attach(dep_id):
    if mt5 is None:
        return False
    mt5.shutdown()
    return bool(mt5.initialize(path=texe(dep_id), portable=True, timeout=15000))


def collect(dep_id, instrument, full_history=False):
    """Read real account/positions/closed trades from the customer's terminal."""
    if not mt5_attach(dep_id):
        return None
    try:
        ai = mt5.account_info()
        ti = mt5.terminal_info()
        if ai is None:
            return None
        connected = bool(ti and ti.connected)
        resolved = resolve_symbol(instrument)
        poss = mt5.positions_get() or []
        account = {
            "deployment_id": dep_id, "connected": connected,
            "balance": ai.balance, "equity": ai.equity, "margin": ai.margin, "free_margin": ai.margin_free,
            "floating": ai.profit, "currency": ai.currency, "leverage": ai.leverage,
            "broker": ai.company, "server": ai.server,
            "positions": [{
                "ticket": p.ticket, "symbol": p.symbol, "type": "buy" if p.type == 0 else "sell", "volume": p.volume,
                "open_price": p.price_open, "sl": p.sl, "tp": p.tp, "profit": p.profit + p.swap,
                "open_time": int(p.time) * 1000} for p in poss]}
        start = datetime.now() - timedelta(days=365 if full_history else 7)
        deals = mt5.history_deals_get(start, datetime.now() + timedelta(days=1)) or []
        by_pos = {}
        for d in deals:
            if d.type not in (0, 1):  # buy/sell only; skip balance, credit, etc.
                continue
            by_pos.setdefault(d.position_id, []).append(d)
        trades = []
        for pid, ds in by_pos.items():
            ins = [d for d in ds if d.entry == 0]
            outs = [d for d in ds if d.entry in (1, 3)]  # DEAL_ENTRY_OUT, OUT_BY
            if not ins or not outs:
                continue
            first, last = ins[0], outs[-1]
            trades.append({
                "ticket": pid, "symbol": first.symbol, "type": "buy" if first.type == 0 else "sell",
                "volume": sum(d.volume for d in ins), "open_time": int(first.time) * 1000, "close_time": int(last.time) * 1000,
                "open_price": first.price, "close_price": last.price,
                "profit": sum(d.profit for d in ds), "swap": sum(d.swap for d in ds), "commission": sum(d.commission + getattr(d, "fee", 0) for d in ds)})
        return account, trades, resolved
    finally:
        mt5.shutdown()


# ---------------------------------------------------------------- commands
def handle(cmd, state):
    t, dep_id = cmd["type"], cmd["deployment_id"]
    key = str(dep_id)
    acct = cmd.get("account")
    conf = cmd.get("config")
    if t == "deploy":
        ensure_template()
        kill(dep_id)
        d = tdir(dep_id)
        if not os.path.exists(texe(dep_id)):
            log(f"Creating isolated terminal for deployment {dep_id}")
            shutil.copytree(CFG["template_dir"], d, dirs_exist_ok=True)
        experts = os.path.join(d, "MQL5", "Experts")
        os.makedirs(experts, exist_ok=True)
        if not os.path.exists(CFG["ea_ex5"]):
            raise RuntimeError("Compiled EA (ALGOEA_IronScalping.ex5) not found on VPS")
        shutil.copy2(CFG["ea_ex5"], os.path.join(experts, "ALGOEA_IronScalping.ex5"))
        restrict_acl(d)
        write_config(dep_id, conf)
        state[key] = {"instrument": conf["instrument"], "symbol": conf["instrument"], "desired": "running", "launched": time.time(), "synced": False}
        launch(dep_id, acct, conf["instrument"])
    elif t == "config":
        write_config(dep_id, conf)
        state.setdefault(key, {})["instrument"] = conf["instrument"]
    elif t in ("start", "restart", "enable_autotrading"):
        if not os.path.exists(texe(dep_id)):
            raise RuntimeError("Terminal not installed. Redeploy first.")
        if t != "start":
            kill(dep_id); time.sleep(3)
        write_config(dep_id, conf)
        s = state.setdefault(key, {})
        s.update(instrument=conf["instrument"], desired="running", launched=time.time())
        if t == "start" and texe(dep_id).lower() in running_terminals():
            return
        launch(dep_id, acct, conf["instrument"], s.get("symbol"))
    elif t == "stop":
        state.setdefault(key, {})["desired"] = "stopped"
        kill(dep_id)
    elif t == "remove":
        kill(dep_id); time.sleep(2)
        shutil.rmtree(tdir(dep_id), ignore_errors=True)
        state.pop(key, None)
    else:
        raise RuntimeError("Unknown command " + t)


# ---------------------------------------------------------------- main loop
def terminal_report(dep_id, st, running):
    stat = read_status(dep_id)
    desired = st.get("desired", "running")
    out = {"deployment_id": dep_id, "mt5_connected": stat.get("connected") == "1", "autotrading": stat.get("autotrading") == "1"}
    if desired == "stopped":
        out["status"] = "stopped"
    elif not running:
        out["status"], out["error"] = "error", "Terminal not running (restarting)"
    elif stat.get("error") and stat["error"].strip():
        out["status"], out["error"] = "error", stat["error"][:250]
    elif stat.get("halted"):
        out["status"], out["error"] = "error", "Protection halt: " + stat["halted"]
    elif time.time() - st.get("launched", 0) < 120 and not stat:
        out["status"] = "deploying"
    elif stat.get("_age", 9999) > 120:
        out["status"], out["error"] = "error", "EA not responding"
    else:
        out["status"] = "running"
    return out


def main():
    global CFG
    if os.name != "nt":
        sys.exit("The ALGOEA agent must run on Windows (MetaTrader 5 is Windows software).")
    if mt5 is None:
        sys.exit("Install the MetaTrader5 python package: pip install MetaTrader5")
    CFG = load_config()
    os.makedirs(os.path.join(CFG["base_dir"], "terminals"), exist_ok=True)
    state = load_state()
    log(f"ALGOEA agent {VERSION} started. API: {CFG['api_url']}")
    last_trades = {}
    while True:
        try:
            running = running_terminals()
            terminals = []
            for key, st in list(state.items()):
                dep_id = int(key)
                is_run = texe(dep_id).lower() in running
                # automatic restart after unexpected shutdown
                if st.get("desired") == "running" and not is_run and os.path.exists(texe(dep_id)) and time.time() - st.get("launched", 0) > 60:
                    log(f"Terminal {dep_id} is not running: restarting automatically")
                    safe_api("/api/agent/log", {"deployment_id": dep_id, "level": "warn", "message": "Terminal stopped unexpectedly. Restarting automatically."})
                    relaunch(dep_id, st.get("instrument", "XAUUSD"), st.get("symbol"))
                    st["launched"] = time.time()
                    is_run = True
                terminals.append(terminal_report(dep_id, st, is_run))
            hb = safe_api("/api/agent/heartbeat", {"cpu_pct": cpu_pct(), "ram_pct": ram_pct(), "hostname": os.environ.get("COMPUTERNAME", ""),
                                                   "agent_version": VERSION, "terminals": terminals})
            if hb:
                for cmd in hb.get("commands", []):
                    try:
                        log(f"Command {cmd['type']} for deployment {cmd['deployment_id']}")
                        handle(cmd, state)
                        save_state(state)
                        safe_api("/api/agent/command-result", {"command_id": cmd["id"], "ok": True})
                    except Exception as e:
                        log(f"Command failed: {e}")
                        safe_api("/api/agent/command-result", {"command_id": cmd["id"], "ok": False, "error": str(e)[:250]})
                        safe_api("/api/agent/log", {"deployment_id": cmd["deployment_id"], "level": "error", "message": f"{cmd['type']} failed: {e}"[:480]})
            # report real MT5 data
            for key, st in list(state.items()):
                dep_id = int(key)
                if st.get("desired") != "running" or texe(dep_id).lower() not in running:
                    continue
                res = collect(dep_id, st.get("instrument", "XAUUSD"), full_history=not st.get("synced"))
                if not res:
                    continue
                account, trades, resolved = res
                if resolved and resolved != st.get("symbol") and time.time() - st.get("launched", 0) > 90:
                    log(f"Broker symbol for deployment {dep_id} is {resolved}: reopening chart")
                    st["symbol"] = resolved
                    kill(dep_id); time.sleep(3)
                    relaunch(dep_id, st.get("instrument", "XAUUSD"), resolved)
                    st["launched"] = time.time()
                safe_api("/api/agent/account", account)
                if trades and (not st.get("synced") or trades != last_trades.get(dep_id)):
                    if safe_api("/api/agent/trades", {"deployment_id": dep_id, "trades": trades}):
                        st["synced"] = True
                        last_trades[dep_id] = trades
                # ship EA error log lines
                try:
                    p = os.path.join(tdir(dep_id), "MQL5", "Files", "algoea_errors.log")
                    if os.path.exists(p):
                        off = st.get("log_off", 0)
                        size = os.path.getsize(p)
                        if size < off:
                            off = 0
                        with open(p, encoding="ascii", errors="ignore") as f:
                            f.seek(off)
                            lines = [l.strip() for l in f.read().splitlines() if l.strip()]
                        if lines:
                            safe_api("/api/agent/log", {"deployment_id": dep_id, "lines": [{"level": "error", "message": l} for l in lines[-40:]]})
                        st["log_off"] = size
                except Exception as e:
                    log(f"log ship error: {e}")
            save_state(state)
        except Exception as e:
            log(f"Loop error: {e}")
        time.sleep(CFG["poll_seconds"])


if __name__ == "__main__":
    main()
