'use strict';
// Loads public/js/app.js in a stub DOM against a throwaway server and renders every page, to catch runtime errors.
const { spawn } = require('node:child_process'); const vm = require('node:vm'); const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const PORT = 4700 + Math.floor(Math.random() * 200), BASE = `http://localhost:${PORT}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'algoea-rc-'));
const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT, DATA_DIR: dir, APP_URL: BASE }, stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  for (let i = 0; i < 50; i++) { try { await fetch(BASE + '/api/config'); break; } catch { await sleep(100); } }
  const els = {}; const el = id => els[id] || (els[id] = { innerHTML: '', className: '', textContent: '', classList: { toggle() {}, add() {}, remove() {} }, querySelector: () => null, closest: () => null });
  const handlers = {}; const errors = [];
  const loc = { hash: '', protocol: 'http:', host: `localhost:${PORT}` };
  const ctx = { console, URLSearchParams, Intl, Date, setTimeout, clearTimeout, Promise, JSON, Math, Number, String, Object, Array, Set, Map, Error, FormData: class { forEach() {} },
    fetch: (u, o) => fetch(BASE + u.replace(BASE, ''), o), location: loc, confirm: () => true, prompt: () => null, WebSocket: undefined,
    document: { querySelector: s => el(s), querySelectorAll: () => [], addEventListener: (t, f) => handlers['d' + t] = f, createElement: () => ({ appendChild() {}, submit() {} }), body: { appendChild() {} }, hidden: false },
    window: { addEventListener: (t, f) => handlers[t] = f, scrollTo() {} } };
  ctx.window.location = loc; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/js/app.js'), 'utf8'), ctx);
  await sleep(600);
  for (const p of ['home', 'about', 'features', 'iron-scalping', 'pricing', 'login', 'register', 'forgot', 'terms', 'privacy', 'support', 'reset?token=abc']) {
    loc.hash = '#/' + p; handlers.hashchange(); await sleep(250);
    const html = el('#app').innerHTML;
    const bad = html.includes('Something went wrong') || html.length < 200;
    console.log(bad ? 'FAIL' : 'ok  ', p, html.length + ' chars'); if (bad) errors.push(p + ': ' + html.slice(0, 200));
  }
  const home = el('#app').innerHTML; loc.hash = '#/home'; handlers.hashchange(); await sleep(250);
  const h = el('#app').innerHTML;
  console.log(['YOUR TRADING.', 'AUTOMATED. HOSTED. CONTROLLED.', 'GET STARTED', 'EXPLORE FEATURES', 'R300', 'financial risk'].map(t => (h.includes(t) || h.toLowerCase().includes(t.toLowerCase()) ? 'has ' : 'MISSING ') + t).join('\n'));
  proc.kill(); fs.rmSync(dir, { recursive: true, force: true });
  if (errors.length) { console.log(errors.join('\n')); process.exit(1); }
})().catch(e => { console.error('CRASH', e); proc.kill(); process.exit(1); });
