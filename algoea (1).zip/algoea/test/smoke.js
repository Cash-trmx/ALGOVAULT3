'use strict';
// End-to-end smoke test. Uses a THROWAWAY database. The "agent" calls below exercise the agent API contract
// with test payloads; nothing here touches production data.
const { spawn } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const PORT = 4100 + Math.floor(Math.random() * 500), BASE = `http://localhost:${PORT}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'algoea-test-'));
let proc, pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  PASS', m); } else { fail++; console.log('  FAIL', m); } };
function start(extraEnv = {}) {
  proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT, DATA_DIR: dir, APP_URL: BASE, RESEND_API_KEY: '', ...extraEnv }, stdio: 'ignore' });
  return new Promise(async res => { for (let i = 0; i < 50; i++) { try { await fetch(BASE + '/api/config'); return res(); } catch { await new Promise(r => setTimeout(r, 100)); } } res(); });
}
const stop = () => new Promise(r => { proc.once('exit', r); proc.kill(); });
class C {
  constructor(key) { this.cookie = ''; this.key = key; }
  async req(method, p, body, raw) {
    const h = { 'Content-Type': 'application/json' };
    if (this.cookie) h.cookie = this.cookie; if (this.key) h.authorization = 'Bearer ' + this.key;
    const r = await fetch(BASE + p, { method, headers: h, body: raw ?? (body ? JSON.stringify(body) : undefined) });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; }
    return { s: r.status, j };
  }
  get(p) { return this.req('GET', p); } post(p, b) { return this.req('POST', p, b || {}); } put(p, b) { return this.req('PUT', p, b); }
}
const dbq = (sql, ...a) => { const d = new DatabaseSync(path.join(dir, 'algoea.db')); try { return d.prepare(sql).all(...a); } finally { d.close(); } };
const dbx = (sql, ...a) => { const d = new DatabaseSync(path.join(dir, 'algoea.db')); try { return d.prepare(sql).run(...a); } finally { d.close(); } };
const linkToken = email => { const rows = dbq("SELECT body FROM outbox WHERE to_email=? ORDER BY id DESC", email); return rows[0].body.match(/token=([\w-]+)/)[1]; };
const PW = 'Str0ngPassw0rd!';
async function register(c, email, name) { await c.post('/api/auth/register', { name, email, password: PW, accept_terms: true }); await c.post('/api/auth/verify', { token: linkToken(email) }); return c.post('/api/auth/login', { email, password: PW }); }

(async () => {
  await start();
  console.log('Auth + admin');
  const adm = new C(), u1 = new C(), u2 = new C(), anon = new C();
  let r = await anon.post('/api/auth/register', { name: 'Eve', email: 'eve@test.com', password: PW, accept_terms: true, is_admin: true, role: 'admin' });
  ok(r.s === 200, 'register accepts valid signup');
  r = await anon.post('/api/auth/login', { email: 'eve@test.com', password: PW });
  ok(r.s === 403, 'login blocked until email verified');
  await anon.post('/api/auth/verify', { token: linkToken('eve@test.com') });
  r = await anon.post('/api/auth/login', { email: 'eve@test.com', password: PW });
  ok(r.s === 200 && r.j.user.is_admin === false, 'self-registration with is_admin flag does NOT grant admin');
  r = await anon.get('/api/admin/overview'); ok(r.s === 403, 'non-admin gets 403 on admin API');
  r = await anon.post('/api/auth/register', { name: 'x', email: 'weak@test.com', password: 'short', accept_terms: true }); ok(r.s === 400, 'weak password rejected');
  r = await register(adm, 'katseatang1@gmail.com', 'Atang'); ok(r.j.user.is_admin === true, 'designated admin email gets admin after verification');
  r = await adm.get('/api/admin/overview'); ok(r.s === 200, 'admin can reach admin API');
  r = await new C().get('/api/dashboard'); ok(r.s === 401, 'unauthenticated blocked');
  r = await new C().post('/api/auth/login', { email: 'eve@test.com', password: 'wrongpassword1' }); ok(r.s === 401, 'wrong password rejected');

  console.log('Subscription gating');
  await register(u1, 'alice@test.com', 'Alice'); await register(u2, 'bob@test.com', 'Bob');
  r = await u1.post('/api/mt5', { login: '1234567', server: 'Demo-Server', password: 'SecretMt5Pw!', instrument: 'XAUUSD' }); ok(r.s === 402, 'cannot add MT5 account without paid subscription');
  const alice = dbq("SELECT id FROM users WHERE email='alice@test.com'")[0].id;
  r = await u1.post(`/api/admin/users/${alice}/activate`, { months: 1, reference: 'EFT123' }); ok(r.s === 403, 'customer cannot self-activate');
  r = await adm.post(`/api/admin/users/${alice}/activate`, { months: 1, reference: 'EFT-REF-1' }); ok(r.s === 200, 'admin verifies payment and activates');
  r = await u1.get('/api/me'); ok(r.j.user.subscription_active === true, 'subscription active after verification');
  r = await adm.get('/api/admin/payments'); ok(r.j.payments.some(p => p.provider === 'manual' && p.status === 'complete'), 'payment recorded in history');

  console.log('MT5 + hosting + agent');
  r = await u1.post('/api/mt5', { login: '1234567', server: 'Demo-Server', password: 'SecretMt5Pw!', instrument: 'XAUUSD', settings: { risk_percent: 50 } }); ok(r.s === 400, 'risk above platform cap rejected');
  r = await u1.post('/api/mt5', { login: '1234567', server: 'Demo-Server', password: 'SecretMt5Pw!', instrument: 'XAUUSD', settings: { risk_percent: 1, lot_mode: 'percent' } }); ok(r.s === 200, 'MT5 account added');
  const acc = r.j.account.id;
  ok(!JSON.stringify(dbq('SELECT password_enc FROM mt5_accounts')).includes('SecretMt5Pw'), 'MT5 password is encrypted at rest');
  r = await u1.post(`/api/mt5/${acc}/deploy`); ok(r.s === 503, 'deploy refused when no VPS capacity');
  r = await adm.post('/api/admin/vps', { name: 'test-vps-1', region: 'ZA', capacity: 5 }); ok(r.s === 200 && r.j.api_key.startsWith('vps_'), 'admin registers VPS and gets one-time key');
  const key1 = r.j.api_key;
  r = await adm.post('/api/admin/vps', { name: 'test-vps-2', capacity: 5 }); const key2 = r.j.api_key;
  const ag1 = new C(key1), ag2 = new C(key2);
  r = await new C('vps_wrong').post('/api/agent/heartbeat', {}); ok(r.s === 401, 'agent with bad key rejected');
  r = await ag1.post('/api/agent/heartbeat', { cpu_pct: 12, ram_pct: 40, hostname: 'T1', agent_version: '1.0.0', terminals: [] }); ok(r.s === 200, 'agent heartbeat ok');
  await ag2.post('/api/agent/heartbeat', { cpu_pct: 1, ram_pct: 1, terminals: [] });
  r = await u1.post(`/api/mt5/${acc}/deploy`); ok(r.s === 200, 'deploy accepted once a VPS is online');
  const depId = r.j.deployment_id;
  const dep = dbq('SELECT vps_id FROM ea_deployments WHERE id=?', depId)[0];
  const vpsKeyFor = dbq('SELECT id FROM vps_instances ORDER BY id').map(x => x.id);
  const owner = dep.vps_id === vpsKeyFor[0] ? ag1 : ag2, other = owner === ag1 ? ag2 : ag1;
  r = await owner.post('/api/agent/heartbeat', { cpu_pct: 20, ram_pct: 41, terminals: [{ deployment_id: depId, status: 'running', mt5_connected: true, autotrading: true }] });
  const cmd = r.j.commands.find(c => c.type === 'deploy');
  ok(cmd && cmd.account.password === 'SecretMt5Pw!' && cmd.config.settings.risk_percent === 1, 'owning agent receives deploy command with decrypted credentials + config');
  r = await other.post('/api/agent/heartbeat', { terminals: [] }); ok(!r.j.commands.length, 'other VPS never receives that customer\'s credentials');
  r = await other.post('/api/agent/account', { deployment_id: depId, balance: 1, equity: 1 }); ok(r.s === 404, 'other VPS cannot report for this deployment');
  r = await owner.post('/api/agent/command-result', { command_id: cmd.id, ok: true }); ok(r.s === 200, 'command result accepted');
  r = await owner.post('/api/agent/account', { deployment_id: depId, connected: true, balance: 1000, equity: 1012.5, margin: 10, free_margin: 990, floating: 12.5, currency: 'USD', leverage: 500, broker: 'Test Broker Ltd', server: 'Demo-Server', positions: [{ ticket: 9, symbol: 'XAUUSD', type: 'buy', volume: 0.05, open_price: 2400.1, sl: 2395, tp: 2410, profit: 12.5 }] });
  ok(r.s === 200, 'agent reports account data');
  const now = Date.now();
  r = await owner.post('/api/agent/trades', { deployment_id: depId, trades: [{ ticket: 1, symbol: 'XAUUSD', type: 'buy', volume: 0.05, open_time: now - 7200e3, close_time: now - 3600e3, open_price: 2390, close_price: 2395, profit: 25, swap: 0, commission: -1 }, { ticket: 2, symbol: 'XAUUSD', type: 'sell', volume: 0.05, open_time: now - 3000e3, close_time: now - 1800e3, open_price: 2400, close_price: 2403, profit: -15, swap: 0, commission: -1 }] });
  ok(r.j.upserted === 2, 'agent reports closed trades');
  r = await u1.get('/api/dashboard'); const d = r.j.data;
  ok(d.live.balance === 1000 && d.live.equity === 1012.5 && d.live.positions.length === 1, 'dashboard shows balance/equity/open trade from agent data');
  ok(d.stats.total_profit === 8 && d.stats.daily_pnl === 8, 'total/daily profit = sum of real closed trades incl. commission (24 + -16 = 8)');
  ok(d.ea.status === 'running' && d.vps.status === 'online', 'EA + VPS status reflected');
  ok(d.performance.daily.length === 30 && d.performance.weekly.length === 12 && d.performance.monthly.length === 12, 'daily/weekly/monthly series present');
  r = await adm.get('/api/admin/mt5'); ok(r.s === 200 && !JSON.stringify(r.j).includes('SecretMt5Pw') && !JSON.stringify(r.j).includes('password'), 'admin MT5 view contains no passwords');

  console.log('Isolation');
  r = await u2.get(`/api/dashboard?account=${acc}`); ok(r.s === 404 || r.j.data === null, 'customer 2 cannot read customer 1 account');
  r = await u2.post(`/api/deployments/${depId}/command`, { action: 'stop' }); ok(r.s === 402 || r.s === 404, 'customer 2 cannot control customer 1 EA');
  r = await u2.post(`/api/mt5/${acc}/deploy`); ok([402, 404].includes(r.s), 'customer 2 cannot deploy customer 1 account');
  r = await u2.get('/api/hosting'); ok(r.j.deployments.length === 0, 'customer 2 hosting page shows nothing of customer 1');

  console.log('Controls + settings');
  r = await u1.post(`/api/deployments/${depId}/command`, { action: 'restart' }); ok(r.s === 200, 'customer can restart EA');
  r = await u1.post(`/api/deployments/${depId}/command`, { action: 'format_disk' }); ok(r.s === 400, 'unknown action rejected');
  r = await u1.put(`/api/mt5/${acc}/settings`, { settings: { max_daily_loss_pct: 99 } }); ok(r.s === 400, 'settings above caps rejected');
  r = await u1.put(`/api/mt5/${acc}/settings`, { settings: { max_daily_loss_pct: 2 } }); ok(r.s === 200, 'valid settings saved');

  console.log('Security');
  r = await new C().req('POST', '/api/auth/login', { email: 'a@b.com', password: 'x' }, 'not json'); ok(r.s === 400, 'bad JSON rejected');
  const raw = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example' }, body: '{}' }); ok(raw.status === 400 || raw.status === 403 || raw.status === 401, 'login endpoint reachable (rate-limit/validation)');
  const raw2 = await fetch(BASE + '/api/me', { method: 'PUT', headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example', cookie: u1.cookie }, body: JSON.stringify({ name: 'Hacked' }) }); ok(raw2.status === 403, 'cross-origin state-changing request blocked (CSRF)');
  const trav = await fetch(BASE + '/..%2f..%2fserver.js'); const tt = await trav.text(); ok(!tt.includes('createServer'), 'static path traversal blocked');
  const hdr = await fetch(BASE + '/'); ok(!!hdr.headers.get('content-security-policy') && hdr.headers.get('x-frame-options') === 'DENY', 'security headers set');
  r = await u1.post('/api/auth/logout-all'); r = await u1.get('/api/me'); ok(r.s === 401, 'logout from all devices invalidates session');

  console.log('Expiry + auto-suspension');
  await u1.post('/api/auth/login', { email: 'alice@test.com', password: PW });
  dbx('UPDATE subscriptions SET ends_at=? WHERE user_id=?', Date.now() - 1000, alice);
  r = await u1.post(`/api/deployments/${depId}/command`, { action: 'start' }); ok(r.s === 402, 'expired subscription blocks EA control immediately');
  await stop(); await start();
  ok(dbq('SELECT status FROM subscriptions WHERE user_id=?', alice)[0].status === 'expired', 'sweep marks subscription expired');
  ok(dbq("SELECT COUNT(*) c FROM commands WHERE deployment_id=? AND type='stop'", depId)[0].c >= 1, 'expiry queues a STOP command for the EA');
  ok(dbq('SELECT desired_state s FROM ea_deployments WHERE id=?', depId)[0].s === 'stopped', 'deployment desired state set to stopped');

  console.log('PayFast');
  await stop();
  await start({ PAYFAST_MERCHANT_ID: '10000100', PAYFAST_MERCHANT_KEY: '46f0cd694581a', PAYFAST_PASSPHRASE: 'jt7NOE43FZPn', PAYFAST_SANDBOX: 'true' });
  await u1.post('/api/auth/login', { email: 'alice@test.com', password: PW });
  r = await u1.post('/api/billing/checkout'); ok(r.s === 200 && r.j.fields.amount === '300.00' && /^[a-f0-9]{32}$/.test(r.j.fields.signature) && r.j.fields.subscription_type === '1', 'checkout builds signed R300 recurring PayFast form');
  const form = new URLSearchParams({ m_payment_id: r.j.fields.m_payment_id, pf_payment_id: '555', payment_status: 'COMPLETE', amount_gross: '300.00', signature: 'f'.repeat(32) }).toString();
  const itn = await new C().req('POST', '/api/billing/payfast/itn', null, form);
  ok(String(itn.j).includes('bad signature'), 'forged ITN rejected');
  r = await u1.get('/api/me'); ok(r.j.user.subscription_active === false, 'forged payment notification does NOT activate account');
  r = await u1.get('/api/billing'); ok(r.j.payments.some(p => p.status === 'pending' || p.provider === 'manual'), 'billing history available');

  console.log('Admin controls');
  r = await adm.post('/api/admin/users/' + alice + '/status', { status: 'suspended' }); ok(r.s === 200, 'admin suspends account');
  r = await new C().post('/api/auth/login', { email: 'alice@test.com', password: PW }); ok(r.s === 403, 'suspended customer cannot log in');
  r = await adm.get('/api/admin/logs?type=audit'); ok(r.j.logs.length > 5, 'audit log recorded actions');
  r = await adm.put('/api/admin/strategy', { settings: { cap_risk_percent: '1.5' } }); ok(r.s === 200, 'admin edits strategy caps');
  const adminId = dbq("SELECT id FROM users WHERE email='katseatang1@gmail.com'")[0].id;
  r = await adm.post(`/api/admin/users/${adminId}/status`, { status: 'suspended' }); ok(r.s === 400, 'admin cannot suspend self');
  ok(dbq('SELECT COUNT(*) c FROM administrators')[0].c === 1, 'exactly one administrator exists');

  await stop();
  fs.rmSync(dir, { recursive: true, force: true });
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(async e => { console.error('TEST CRASH', e); try { await stop(); } catch { } process.exit(1); });
