'use strict';
// Renders logged-in pages (dashboard, mt5, hosting, account, billing, support, all admin tabs) with test data.
const { spawn } = require('node:child_process'); const vm = require('node:vm'); const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const PORT = 4900 + Math.floor(Math.random() * 200), BASE = `http://localhost:${PORT}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'algoea-ra-'));
const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT, DATA_DIR: dir, APP_URL: BASE }, stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let cookie = '';
const call = async (m, p, b, key) => { const h = { 'Content-Type': 'application/json' }; if (cookie) h.cookie = cookie; if (key) h.authorization = 'Bearer ' + key; const r = await fetch(BASE + p, { method: m, headers: h, body: b ? JSON.stringify(b) : undefined }); const sc = r.headers.get('set-cookie'); if (sc && !key) cookie = sc.split(';')[0]; return r.json().catch(() => ({})); };
(async () => {
  for (let i = 0; i < 50; i++) { try { await fetch(BASE + '/api/config'); break; } catch { await sleep(100); } }
  const PW = 'Str0ngPassw0rd!', email = 'katseatang1@gmail.com';
  await call('POST', '/api/auth/register', { name: 'Atang', email, password: PW, accept_terms: true });
  const db = new DatabaseSync(path.join(dir, 'algoea.db'));
  const tok = db.prepare('SELECT body FROM outbox ORDER BY id DESC').get().body.match(/token=([\w-]+)/)[1];
  await call('POST', '/api/auth/verify', { token: tok }); await call('POST', '/api/auth/login', { email, password: PW });
  const uid = db.prepare('SELECT id FROM users').get().id;
  await call('POST', `/api/admin/users/${uid}/activate`, { months: 1, reference: 'TEST-REF' });
  const v = await call('POST', '/api/admin/vps', { name: 'vps-a', region: 'ZA', capacity: 3 });
  await call('POST', '/api/agent/heartbeat', { cpu_pct: 10, ram_pct: 30, terminals: [] }, v.api_key);
  const a = await call('POST', '/api/mt5', { login: '7654321', server: 'Demo-Srv', password: 'pw', instrument: 'XAUUSD', settings: {} });
  const dep = await call('POST', `/api/mt5/${a.account.id}/deploy`);
  await call('POST', '/api/agent/heartbeat', { terminals: [{ deployment_id: dep.deployment_id, status: 'running', mt5_connected: true, autotrading: true }] }, v.api_key);
  await call('POST', '/api/agent/account', { deployment_id: dep.deployment_id, balance: 1000, equity: 1010, margin: 5, free_margin: 900, floating: 10, currency: 'USD', leverage: 500, broker: 'B', server: 'S', positions: [{ ticket: 1, symbol: 'XAUUSD', type: 'buy', volume: .1, open_price: 2400, sl: 2390, tp: 2420, profit: 10 }] }, v.api_key);
  const now = Date.now();
  await call('POST', '/api/agent/trades', { deployment_id: dep.deployment_id, trades: [{ ticket: 5, symbol: 'XAUUSD', type: 'buy', volume: .1, open_time: now - 9e6, close_time: now - 8e6, open_price: 1, close_price: 2, profit: 30, swap: 0, commission: -1 }] }, v.api_key);
  await call('POST', '/api/agent/log', { deployment_id: dep.deployment_id, level: 'error', message: 'test <b>log</b>' }, v.api_key);
  await call('POST', '/api/support', { subject: 'Hello', message: 'Need <script>help</script>' });

  const els = {}; const el = id => els[id] || (els[id] = { innerHTML: '', className: '', textContent: '', dataset: {}, classList: { toggle() {} }, querySelector: () => null });
  const handlers = {}; const loc = { hash: '', protocol: 'http:', host: `localhost:${PORT}` };
  const ctx = { console, URLSearchParams, Intl, Date, setTimeout, clearTimeout, Promise, JSON, Math, Number, String, Object, Array, Set, Map, Error, FormData: class { forEach() {} },
    fetch: (u, o) => { o = o || {}; o.headers = { ...(o.headers || {}), cookie }; return fetch(BASE + u, o); }, location: loc, confirm: () => true, prompt: () => null, WebSocket: undefined,
    document: { querySelector: s => el(s), querySelectorAll: () => [], addEventListener: (t, f) => handlers['d' + t] = f, createElement: () => ({ appendChild() {}, submit() {} }), body: { appendChild() {} }, hidden: false },
    window: { addEventListener: (t, f) => handlers[t] = f, scrollTo() {} } };
  vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/js/app.js'), 'utf8'), ctx);
  await sleep(700);
  let fails = 0;
  for (const p of ['dashboard', 'mt5', 'hosting', 'account', 'pricing', 'support', 'support?t=1', 'admin']) {
    loc.hash = '#/' + p; handlers.hashchange(); await sleep(400);
    const html = el('#app').innerHTML; const bad = html.includes('Something went wrong') || html.length < 300;
    if (bad) fails++; console.log(bad ? 'FAIL' : 'ok  ', p, html.length, bad ? html.slice(0, 160) : '');
    if (p === 'dashboard') console.log('     ', ['1 010', 'Connected', 'RESTART EA', 'Open trades', 'Equity curve'].map(t => (html.includes(t) || html.includes(t.replace(' ', ' ')) ? 'has ' : 'MISSING ') + t).join(' | '), '| raw-script-escaped:', !html.includes('<script>'));
  }
  // admin tabs through the exposed click handler
  for (const tab of ['users', 'payments', 'mt5', 'vps', 'strategy', 'settings', 'tickets', 'logs']) {
    const btn = { dataset: { act: 'a-tab', k: tab } };
    handlers.dclick({ target: { closest: () => btn }, preventDefault() {} }); await sleep(350);
    const html = el('#adminBody').innerHTML; const bad = !html || html.length < 80 || html.includes('undefined');
    if (bad) fails++; console.log(bad ? 'FAIL' : 'ok  ', 'admin/' + tab, html.length);
  }
  proc.kill(); fs.rmSync(dir, { recursive: true, force: true }); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('CRASH', e); proc.kill(); process.exit(1); });
