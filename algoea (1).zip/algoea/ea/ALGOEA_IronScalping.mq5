//+------------------------------------------------------------------+
//|                                       ALGOEA_IronScalping.mq5    |
//|  ALGOEA IRON SCALPING - multi-timeframe structure EA (MT5)       |
//|                                                                  |
//|  Settings are read from MQL5/Files/algoea_config.ini, which the  |
//|  ALGOEA VPS agent writes. Hard safety caps below are compiled in |
//|  and cannot be exceeded by any config value.                     |
//|                                                                  |
//|  RISK WARNING: Trading is risky and profits are not guaranteed.  |
//|  Compile in MetaEditor and test on a DEMO account first.         |
//+------------------------------------------------------------------+
#property copyright "ALGOEA"
#property version   "1.00"
#property strict

#include <Trade/Trade.mqh>

#define EA_VERSION "1.0.0"

//--- compiled-in hard caps (config values are clamped to these)
input double InpHardMaxRiskPct   = 2.0;     // absolute max risk per trade %
input double InpHardMaxLot       = 1.0;     // absolute max lot
input double InpHardMaxDailyLoss = 10.0;    // absolute max daily loss %
input double InpHardMaxDrawdown  = 30.0;    // absolute max drawdown %
input long   InpMagic            = 26110701;
input string InpConfigFile       = "algoea_config.ini";
input string InpStatusFile       = "algoea_status.txt";
input string InpErrorLog         = "algoea_errors.log";

//--- runtime settings (loaded from config)
struct Cfg
{
   bool   enabled;
   string instrument;
   string lot_mode;          // "percent" | "fixed"
   double fixed_lot;
   double risk_percent;
   double rr;
   double max_daily_loss_pct;
   double max_drawdown_pct;
   double max_spread_points;
   int    max_open_trades;
   int    session_start_hour;
   int    session_end_hour;
   bool   use_m1_entries;
   bool   use_trailing;
   bool   use_breakeven;
};
Cfg g_cfg;

CTrade   g_trade;
int      g_atrM5 = INVALID_HANDLE, g_emaFast = INVALID_HANDLE, g_emaSlow = INVALID_HANDLE, g_emaH4 = INVALID_HANDLE;
datetime g_lastM5 = 0, g_lastM1 = 0, g_lastCfg = 0, g_lastStatus = 0;
string   g_lastError = "";
bool     g_halted = false;
string   g_haltReason = "";
double   g_dayStartEquity = 0;
int      g_dayOfYear = -1;
string   g_gvPeak, g_gvHalt, g_gvDay, g_gvDayId;

//+------------------------------------------------------------------+
void LogError(string msg)
{
   g_lastError = msg;
   Print("ALGOEA ERROR: ", msg);
   int h = FileOpen(InpErrorLog, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(h != INVALID_HANDLE)
   {
      FileSeek(h, 0, SEEK_END);
      FileWriteString(h, TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS) + " " + msg + "\r\n");
      FileClose(h);
   }
}

void DefaultCfg()
{
   g_cfg.enabled = false;               // do not trade until a config has been loaded
   g_cfg.instrument = "XAUUSD";
   g_cfg.lot_mode = "percent";
   g_cfg.fixed_lot = 0.01;
   g_cfg.risk_percent = 0.5;
   g_cfg.rr = 1.5;
   g_cfg.max_daily_loss_pct = 3.0;
   g_cfg.max_drawdown_pct = 10.0;
   g_cfg.max_spread_points = 40;
   g_cfg.max_open_trades = 1;
   g_cfg.session_start_hour = 8;
   g_cfg.session_end_hour = 20;
   g_cfg.use_m1_entries = false;
   g_cfg.use_trailing = true;
   g_cfg.use_breakeven = true;
}

bool LoadConfig()
{
   int h = FileOpen(InpConfigFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(h == INVALID_HANDLE) return false;
   Cfg c = g_cfg;
   while(!FileIsEnding(h))
   {
      string line = FileReadString(h);
      StringTrimLeft(line); StringTrimRight(line);
      int p = StringFind(line, "=");
      if(p < 1) continue;
      string k = StringSubstr(line, 0, p), v = StringSubstr(line, p + 1);
      if(k == "enabled") c.enabled = (v == "1" || v == "true");
      else if(k == "instrument") c.instrument = v;
      else if(k == "lot_mode") c.lot_mode = v;
      else if(k == "fixed_lot") c.fixed_lot = StringToDouble(v);
      else if(k == "risk_percent") c.risk_percent = StringToDouble(v);
      else if(k == "rr") c.rr = StringToDouble(v);
      else if(k == "max_daily_loss_pct") c.max_daily_loss_pct = StringToDouble(v);
      else if(k == "max_drawdown_pct") c.max_drawdown_pct = StringToDouble(v);
      else if(k == "max_spread_points") c.max_spread_points = StringToDouble(v);
      else if(k == "max_open_trades") c.max_open_trades = (int)StringToInteger(v);
      else if(k == "session_start_hour") c.session_start_hour = (int)StringToInteger(v);
      else if(k == "session_end_hour") c.session_end_hour = (int)StringToInteger(v);
      else if(k == "use_m1_entries") c.use_m1_entries = (v == "1" || v == "true");
      else if(k == "use_trailing") c.use_trailing = (v == "1" || v == "true");
      else if(k == "use_breakeven") c.use_breakeven = (v == "1" || v == "true");
   }
   FileClose(h);
   // clamp to hard caps
   c.risk_percent = MathMax(0.05, MathMin(c.risk_percent, InpHardMaxRiskPct));
   c.fixed_lot = MathMax(0.01, MathMin(c.fixed_lot, InpHardMaxLot));
   c.max_daily_loss_pct = MathMax(0.1, MathMin(c.max_daily_loss_pct, InpHardMaxDailyLoss));
   c.max_drawdown_pct = MathMax(0.5, MathMin(c.max_drawdown_pct, InpHardMaxDrawdown));
   c.rr = MathMax(0.5, MathMin(c.rr, 5.0));
   c.max_open_trades = MathMax(1, MathMin(c.max_open_trades, 5));
   c.session_start_hour = MathMax(0, MathMin(c.session_start_hour, 23));
   c.session_end_hour = MathMax(1, MathMin(c.session_end_hour, 24));
   g_cfg = c;
   return true;
}

//+------------------------------------------------------------------+
//| Indicators / structure                                           |
//+------------------------------------------------------------------+
double Buf(int handle, int shift)
{
   double b[1];
   if(CopyBuffer(handle, 0, shift, 1, b) != 1) return 0;
   return b[0];
}

// two most recent confirmed swing highs/lows (fractal, 2 bars each side). hi1/lo1 = most recent
bool Swings(ENUM_TIMEFRAMES tf, double &hi1, double &hi2, double &lo1, double &lo2)
{
   hi1 = hi2 = lo1 = lo2 = 0;
   int fh = 0, fl = 0;
   for(int i = 3; i < 150; i++)
   {
      double h = iHigh(_Symbol, tf, i), l = iLow(_Symbol, tf, i);
      if(h == 0 || l == 0) break;
      bool isH = h > iHigh(_Symbol, tf, i + 1) && h > iHigh(_Symbol, tf, i + 2) && h > iHigh(_Symbol, tf, i - 1) && h > iHigh(_Symbol, tf, i - 2);
      bool isL = l < iLow(_Symbol, tf, i + 1) && l < iLow(_Symbol, tf, i + 2) && l < iLow(_Symbol, tf, i - 1) && l < iLow(_Symbol, tf, i - 2);
      if(isH) { if(fh == 0) { hi1 = h; fh = 1; } else if(fh == 1) { hi2 = h; fh = 2; } }
      if(isL) { if(fl == 0) { lo1 = l; fl = 1; } else if(fl == 1) { lo2 = l; fl = 2; } }
      if(fh == 2 && fl == 2) return true;
   }
   return false;
}

// +1 = higher highs & higher lows, -1 = lower highs & lower lows, 0 = no clear structure
int StructureTrend(ENUM_TIMEFRAMES tf)
{
   double h1, h2, l1, l2;
   if(!Swings(tf, h1, h2, l1, l2)) return 0;
   if(h1 > h2 && l1 > l2) return 1;
   if(h1 < h2 && l1 < l2) return -1;
   return 0;
}

// higher timeframe trend: H1 EMA50 vs EMA200 and H4 price vs EMA50 must agree
int HigherTimeframeTrend()
{
   double f = Buf(g_emaFast, 1), s = Buf(g_emaSlow, 1), h4 = Buf(g_emaH4, 1);
   double c1 = iClose(_Symbol, PERIOD_H1, 1), c4 = iClose(_Symbol, PERIOD_H4, 1);
   if(f == 0 || s == 0 || h4 == 0) return 0;
   if(f > s && c1 > f && c4 > h4) return 1;
   if(f < s && c1 < f && c4 < h4) return -1;
   return 0;
}

// break of structure on tf in direction dir (last closed bar closes beyond the last swing)
bool BreakOfStructure(ENUM_TIMEFRAMES tf, int dir, double &swingOpposite)
{
   double h1, h2, l1, l2;
   if(!Swings(tf, h1, h2, l1, l2)) return false;
   double c1 = iClose(_Symbol, tf, 1), c2 = iClose(_Symbol, tf, 2);
   if(dir > 0 && c1 > h1 && c2 <= h1) { swingOpposite = l1; return true; }
   if(dir < 0 && c1 < l1 && c2 >= l1) { swingOpposite = h1; return true; }
   return false;
}

bool VolatilityOk()
{
   double a[];
   ArraySetAsSeries(a, true);
   if(CopyBuffer(g_atrM5, 0, 1, 50, a) != 50) return false;
   double avg = 0;
   for(int i = 0; i < 50; i++) avg += a[i];
   avg /= 50.0;
   if(avg <= 0) return false;
   double ratio = a[0] / avg;
   return ratio >= 0.5 && ratio <= 2.5;      // skip dead markets and spikes
}

bool SpreadOk() { return (double)SymbolInfoInteger(_Symbol, SYMBOL_SPREAD) <= g_cfg.max_spread_points; }

bool SessionOk()
{
   MqlDateTime t; TimeToStruct(TimeCurrent(), t);
   return t.hour >= g_cfg.session_start_hour && t.hour < g_cfg.session_end_hour;
}

//+------------------------------------------------------------------+
//| Risk protection                                                  |
//+------------------------------------------------------------------+
int CountPositions()
{
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong tk = PositionGetTicket(i);
      if(tk == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) == InpMagic && PositionGetString(POSITION_SYMBOL) == _Symbol) n++;
   }
   return n;
}

void CloseAll(string why)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong tk = PositionGetTicket(i);
      if(tk == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpMagic) continue;
      if(!g_trade.PositionClose(tk)) LogError("Close failed (" + why + ") ticket " + (string)tk + " err " + (string)GetLastError());
   }
}

void UpdateProtection()
{
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   MqlDateTime t; TimeToStruct(TimeCurrent(), t);
   int dayId = t.year * 1000 + t.day_of_year;
   if(g_dayOfYear != dayId)
   {
      g_dayOfYear = dayId;
      g_dayStartEquity = AccountInfoDouble(ACCOUNT_BALANCE) > eq ? AccountInfoDouble(ACCOUNT_BALANCE) : eq;
      GlobalVariableSet(g_gvDay, g_dayStartEquity);
      GlobalVariableSet(g_gvDayId, dayId);
      if(g_haltReason == "daily_loss") { g_halted = false; g_haltReason = ""; }
   }
   double peak = GlobalVariableCheck(g_gvPeak) ? GlobalVariableGet(g_gvPeak) : eq;
   if(eq > peak) peak = eq;
   GlobalVariableSet(g_gvPeak, peak);

   if(!g_halted)
   {
      if(g_dayStartEquity > 0 && (g_dayStartEquity - eq) / g_dayStartEquity * 100.0 >= g_cfg.max_daily_loss_pct)
      {
         g_halted = true; g_haltReason = "daily_loss";
         LogError("Max daily loss reached. Closing positions and pausing until next day.");
         CloseAll("daily loss");
      }
      else if(peak > 0 && (peak - eq) / peak * 100.0 >= g_cfg.max_drawdown_pct)
      {
         g_halted = true; g_haltReason = "drawdown";
         GlobalVariableSet(g_gvHalt, 1);
         LogError("Max drawdown reached. Closing positions. Trading is halted until manually cleared.");
         CloseAll("drawdown");
      }
   }
}

//+------------------------------------------------------------------+
//| Position sizing and orders                                       |
//+------------------------------------------------------------------+
double NormalizeLot(double lots)
{
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double mn = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN), mx = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   if(step <= 0) step = 0.01;
   lots = MathFloor(lots / step) * step;
   lots = MathMax(mn, MathMin(lots, MathMin(mx, InpHardMaxLot)));
   return NormalizeDouble(lots, 2);
}

double CalcLots(double slDistance)
{
   if(g_cfg.lot_mode == "fixed") return NormalizeLot(MathMin(g_cfg.fixed_lot, InpHardMaxLot));
   double tickVal = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickVal <= 0 || tickSize <= 0 || slDistance <= 0) return 0;
   double riskMoney = AccountInfoDouble(ACCOUNT_EQUITY) * g_cfg.risk_percent / 100.0;
   double lossPerLot = slDistance / tickSize * tickVal;
   if(lossPerLot <= 0) return 0;
   return NormalizeLot(riskMoney / lossPerLot);
}

void OpenTrade(int dir, double swingOpposite, string tag)
{
   double atr = Buf(g_atrM5, 1);
   if(atr <= 0) return;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick)) return;
   double price = dir > 0 ? tick.ask : tick.bid;
   double stopsLvl = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   double buffer = 0.25 * atr;
   double slDist = dir > 0 ? price - (swingOpposite - buffer) : (swingOpposite + buffer) - price;
   slDist = MathMax(slDist, 1.0 * atr);         // never tighter than 1 ATR
   slDist = MathMin(slDist, 3.0 * atr);         // never wider than 3 ATR
   slDist = MathMax(slDist, stopsLvl + 2 * _Point);
   double sl = dir > 0 ? price - slDist : price + slDist;
   double tp = dir > 0 ? price + slDist * g_cfg.rr : price - slDist * g_cfg.rr;
   double lots = CalcLots(slDist);
   if(lots <= 0) { LogError("Lot calculation returned 0"); return; }
   sl = NormalizeDouble(sl, _Digits); tp = NormalizeDouble(tp, _Digits);
   bool ok = dir > 0 ? g_trade.Buy(lots, _Symbol, 0, sl, tp, "ALGOEA " + tag) : g_trade.Sell(lots, _Symbol, 0, sl, tp, "ALGOEA " + tag);
   if(!ok) LogError("Order failed: " + (string)g_trade.ResultRetcode() + " " + g_trade.ResultRetcodeDescription());
   else
   {
      ulong tk = g_trade.ResultOrder();
      // remember the initial risk distance for break-even / trailing (keyed by position ticket)
      GlobalVariableSet("ALGOEA_R_" + (string)tk, slDist);
   }
}

bool EntryAllowed()
{
   if(!g_cfg.enabled || g_halted) return false;
   if(StringFind(_Symbol, g_cfg.instrument) != 0) return false;
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED) || !AccountInfoInteger(ACCOUNT_TRADE_ALLOWED)) return false;
   if(!SessionOk() || !SpreadOk() || !VolatilityOk()) return false;
   if(CountPositions() >= g_cfg.max_open_trades) return false;
   return true;
}

void TryEntry(ENUM_TIMEFRAMES entryTf, string tag)
{
   if(!EntryAllowed()) return;
   int htf = HigherTimeframeTrend();
   if(htf == 0) return;
   if(StructureTrend(PERIOD_M15) != htf) return;
   if(entryTf == PERIOD_M1 && StructureTrend(PERIOD_M5) != htf) return;
   double opp;
   if(BreakOfStructure(entryTf, htf, opp)) OpenTrade(htf, opp, tag);
}

//+------------------------------------------------------------------+
//| Trade management: break-even and trailing                        |
//+------------------------------------------------------------------+
void ManagePositions()
{
   double atr = Buf(g_atrM5, 1);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong tk = PositionGetTicket(i);
      if(tk == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpMagic || PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      string gv = "ALGOEA_R_" + (string)tk;
      if(!GlobalVariableCheck(gv)) continue;
      double r = GlobalVariableGet(gv);
      long type = PositionGetInteger(POSITION_TYPE);
      double open = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP);
      double price = type == POSITION_TYPE_BUY ? SymbolInfoDouble(_Symbol, SYMBOL_BID) : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double profitDist = type == POSITION_TYPE_BUY ? price - open : open - price;
      double newSl = sl;
      double spreadPad = (double)SymbolInfoInteger(_Symbol, SYMBOL_SPREAD) * _Point;
      if(g_cfg.use_breakeven && profitDist >= r)
      {
         double be = type == POSITION_TYPE_BUY ? open + spreadPad : open - spreadPad;
         if(type == POSITION_TYPE_BUY ? be > newSl : (newSl == 0 || be < newSl)) newSl = be;
      }
      if(g_cfg.use_trailing && atr > 0 && profitDist >= 1.5 * r)
      {
         double tr = type == POSITION_TYPE_BUY ? price - atr : price + atr;
         if(type == POSITION_TYPE_BUY ? tr > newSl : (newSl == 0 || tr < newSl)) newSl = tr;
      }
      newSl = NormalizeDouble(newSl, _Digits);
      double minStep = 2 * _Point;
      if(newSl != sl && MathAbs(newSl - sl) > minStep)
      {
         double lvl = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
         bool valid = type == POSITION_TYPE_BUY ? (price - newSl) > lvl : (newSl - price) > lvl;
         if(valid && !g_trade.PositionModify(tk, newSl, tp)) LogError("Modify failed ticket " + (string)tk + " err " + (string)GetLastError());
      }
   }
}

//+------------------------------------------------------------------+
//| Status file for the ALGOEA agent                                 |
//+------------------------------------------------------------------+
void WriteStatus()
{
   int h = FileOpen(InpStatusFile, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, "version=" + EA_VERSION + "\r\n");
   FileWriteString(h, "time=" + (string)(long)TimeLocal() + "\r\n");
   FileWriteString(h, "symbol=" + _Symbol + "\r\n");
   FileWriteString(h, "enabled=" + (g_cfg.enabled ? "1" : "0") + "\r\n");
   FileWriteString(h, "autotrading=" + ((TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) && MQLInfoInteger(MQL_TRADE_ALLOWED)) ? "1" : "0") + "\r\n");
   FileWriteString(h, "connected=" + (TerminalInfoInteger(TERMINAL_CONNECTED) ? "1" : "0") + "\r\n");
   FileWriteString(h, "halted=" + (g_halted ? g_haltReason : "") + "\r\n");
   FileWriteString(h, "error=" + g_lastError + "\r\n");
   FileClose(h);
}

//+------------------------------------------------------------------+
int OnInit()
{
   DefaultCfg();
   long login = AccountInfoInteger(ACCOUNT_LOGIN);
   g_gvPeak = "ALGOEA_PEAK_" + (string)login;
   g_gvHalt = "ALGOEA_HALT_" + (string)login;
   g_gvDay = "ALGOEA_DAYSTART_" + (string)login;
   g_gvDayId = "ALGOEA_DAYID_" + (string)login;
   if(GlobalVariableCheck(g_gvHalt) && GlobalVariableGet(g_gvHalt) > 0) { g_halted = true; g_haltReason = "drawdown"; }
   if(GlobalVariableCheck(g_gvDay) && GlobalVariableCheck(g_gvDayId))
   {
      g_dayStartEquity = GlobalVariableGet(g_gvDay);
      g_dayOfYear = (int)GlobalVariableGet(g_gvDayId);
   }
   g_atrM5 = iATR(_Symbol, PERIOD_M5, 14);
   g_emaFast = iMA(_Symbol, PERIOD_H1, 50, 0, MODE_EMA, PRICE_CLOSE);
   g_emaSlow = iMA(_Symbol, PERIOD_H1, 200, 0, MODE_EMA, PRICE_CLOSE);
   g_emaH4 = iMA(_Symbol, PERIOD_H4, 50, 0, MODE_EMA, PRICE_CLOSE);
   if(g_atrM5 == INVALID_HANDLE || g_emaFast == INVALID_HANDLE || g_emaSlow == INVALID_HANDLE || g_emaH4 == INVALID_HANDLE)
   { LogError("Indicator handle creation failed"); return INIT_FAILED; }
   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(30);
   g_trade.SetTypeFillingBySymbol(_Symbol);
   if(!LoadConfig()) LogError("Config file not found: waiting for ALGOEA agent");
   g_lastCfg = TimeLocal();
   EventSetTimer(5);
   WriteStatus();
   Print("ALGOEA IRON SCALPING ", EA_VERSION, " started on ", _Symbol);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   IndicatorRelease(g_atrM5); IndicatorRelease(g_emaFast); IndicatorRelease(g_emaSlow); IndicatorRelease(g_emaH4);
   WriteStatus();
}

void OnTimer()
{
   if(TimeLocal() - g_lastCfg >= 30)
   {
      if(LoadConfig() && StringFind(g_lastError, "Config file not found") == 0) g_lastError = "";
      g_lastCfg = TimeLocal();
   }
   WriteStatus();
}

void OnTick()
{
   UpdateProtection();
   ManagePositions();
   datetime m5 = iTime(_Symbol, PERIOD_M5, 0);
   if(m5 != g_lastM5) { g_lastM5 = m5; TryEntry(PERIOD_M5, "M5"); }
   if(g_cfg.use_m1_entries)
   {
      datetime m1 = iTime(_Symbol, PERIOD_M1, 0);
      if(m1 != g_lastM1) { g_lastM1 = m1; TryEntry(PERIOD_M1, "M1"); }
   }
}
//+------------------------------------------------------------------+
