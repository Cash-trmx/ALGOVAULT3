'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// ---------- env ----------
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
} catch { /* no .env */ }

const PORT = +process.env.PORT || 3000;
const APP_URL = (process.env.APP_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'katseatang1@gmail.com').toLowerCase();
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const SECURE_COOKIE = APP_URL.startsWith('https');

const sec = require('./lib/security');
const db = require('./lib/db').open(path.join(DATA_DIR, 'algoea.db'));
const mail = require('./lib/mail')(db);
const MASTER = sec.loadMasterKey(DATA_DIR);

// Only ADMIN_EMAIL may ever hold admin rights.
db.prepare('DELETE FROM administrators WHERE user_id NOT IN (SELECT id FROM users WHERE email=? AND email_verified=1)').run(ADMIN_EMAIL);

// ---------- helpers ----------
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m, s = 400) => new HttpError(s, m);
const now = () => Date.now();
const DAY = 86400e3;
const q = (sql, ...p) => db.prepare(sql).all(...p);
const q1 = (sql, ...p) => db.prepare(sql).get(...p);
const run = (sql, ...p) => db.prepare(sql).run(...p);
const setting = k => q1('SELECT value FROM settings WHERE key=?', k)?.value;
const numSetting = k => Number(setting(k));
const syslog = (level, source, message) => run('INSERT INTO system_logs(level,source,message,ts) VALUES(?,?,?,?)', level, source, String(message).slice(0, 1000), now());
const audit = (userId, action, target, meta, ip) => run('INSERT INTO audit_logs(user_id,action,target,meta,ip,ts) VALUES(?,?,?,?,?,?)', userId ?? null, action, target ?? null, meta ? JSON.stringify(meta) : null, ip ?? null, now());
const notify = (userId, title, body) => { run('INSERT INTO notifications(user_id,title,body,created_at) VALUES(?,?,?,?)', userId, title, body, now()); ws.push(userId, { type: 'notification' }); };
const str = (v, min, max, name) => {
  if (typeof v !== 'string') throw bad(`${name} is required`);
  v = v.trim();
  if (v.length < min || v.length > max) throw bad(`${name} must be ${min}-${max} characters`);
  return v;
};
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// ---------- sessions ----------
function createSession(userId, req) {
  const token = sec.randomToken(32);
  run('INSERT INTO sessions(token_hash,user_id,created_at,expires_at,ip,user_agent) VALUES(?,?,?,?,?,?)',
    sec.sha256(token), userId, now(), now() + 30 * DAY, clientIp(req), String(req.headers['user-agent'] || '').slice(0, 200));
  return token;
}
function clientIp(req) { return String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }
function userFromRequest(req) {
  let token = sec.parseCookies(req.headers.cookie).algoea_session;
  const a = req.headers.authorization;
  if (!token && a && a.startsWith('Bearer ')) token = a.slice(7);
  if (!token) return null;
  const s = q1('SELECT * FROM sessions WHERE token_hash=?', sec.sha256(token));
  if (!s || s.expires_at < now()) return null;
  const u = q1('SELECT * FROM users WHERE id=?', s.user_id);
  if (!u || u.status !== 'active') return null;
  u.is_admin = !!q1('SELECT 1 x FROM administrators WHERE user_id=?', u.id) && u.email.toLowerCase() === ADMIN_EMAIL;
  u._sessionHash = s.token_hash;
  return u;
}
const wsApi = require('./lib/ws');
let ws = { push() {} };

// ---------- subscription logic ----------
const subOf = id => q1('SELECT * FROM subscriptions WHERE user_id=?', id);
const hasActiveSub = id => { const s = subOf(id); return !!s && s.status === 'active' && s.ends_at > now(); };
function addMonths(ts, m) { const d = new Date(ts); d.setUTCMonth(d.getUTCMonth() + m); return d.getTime(); }
function extendSubscription(userId, months, token) {
  const s = subOf(userId), t = now();
  const base = s && s.status === 'active' && s.ends_at > t ? s.ends_at : t;
  const ends = addMonths(base, months);
  if (s) run("UPDATE subscriptions SET status='active', starts_at=COALESCE(CASE WHEN status='active' AND ends_at>? THEN starts_at END,?), ends_at=?, payfast_token=COALESCE(?,payfast_token) WHERE user_id=?", t, t, ends, token ?? null, userId);
  else run("INSERT INTO subscriptions(user_id,status,starts_at,ends_at,auto_renew,payfast_token,created_at) VALUES(?,'active',?,?,1,?,?)", userId, t, ends, token ?? null, t);
  ws.push(userId, { type: 'subscription' });
  return ends;
}
function suspendAccess(userId, reason) {
  for (const d of q('SELECT * FROM ea_deployments WHERE user_id=?', userId)) {
    run("UPDATE ea_deployments SET desired_state='stopped' WHERE id=?", d.id);
    if (d.vps_id) queueCommand(d.vps_id, d.id, 'stop');
  }
  notify(userId, 'Access suspended', reason);
}
function sweep() {
  const t = now();
  for (const s of q("SELECT * FROM subscriptions WHERE status='active' AND ends_at<=?", t)) {
    run("UPDATE subscriptions SET status='expired' WHERE id=?", s.id);
    suspendAccess(s.user_id, 'Your ALGOEA PREMIUM subscription has expired. Your EA has been stopped. Renew to restore access.');
    syslog('info', 'billing', `Subscription expired for user ${s.user_id}`);
  }
  for (const s of q("SELECT * FROM subscriptions WHERE status='active' AND ends_at BETWEEN ? AND ? AND auto_renew=0", t, t + 3 * DAY)) {
    if (!q1("SELECT 1 x FROM notifications WHERE user_id=? AND title='Subscription ending soon' AND created_at>?", s.user_id, t - 3 * DAY))
      notify(s.user_id, 'Subscription ending soon', 'Your subscription ends on ' + new Date(s.ends_at).toISOString().slice(0, 10) + ' and will not renew automatically.');
  }
  for (const v of q("SELECT * FROM vps_instances WHERE status='online' AND last_seen<?", t - 90e3)) {
    run("UPDATE vps_instances SET status='offline' WHERE id=?", v.id);
    syslog('warn', 'vps', `VPS ${v.name} went offline (no heartbeat)`);
    for (const d of q('SELECT user_id FROM ea_deployments WHERE vps_id=?', v.id)) ws.push(d.user_id, { type: 'status' });
  }
  run('DELETE FROM sessions WHERE expires_at<?', t);
  run('DELETE FROM email_tokens WHERE expires_at<?', t - DAY);
}
setInterval(() => { try { sweep(); } catch (e) { console.error('sweep', e); } }, 60e3).unref();

// ---------- risk settings ----------
const DEFAULT_RISK = {
  lot_mode: 'percent', fixed_lot: 0.01, risk_percent: 0.5, rr: 1.5,
  max_daily_loss_pct: 3, max_drawdown_pct: 10, max_spread_points: 40, max_open_trades: 1,
  session_start_hour: 8, session_end_hour: 20, use_m1_entries: false, use_trailing: true, use_breakeven: true
};
function validateRisk(input, base = DEFAULT_RISK) {
  const r = { ...base };
  const num = (k, min, max) => {
    if (input[k] === undefined) return;
    const n = Number(input[k]);
    if (!Number.isFinite(n) || n < min || n > max) throw bad(`${k} must be between ${min} and ${max}`);
    r[k] = n;
  };
  if (input.lot_mode !== undefined) { if (!['fixed', 'percent'].includes(input.lot_mode)) throw bad('lot_mode must be fixed or percent'); r.lot_mode = input.lot_mode; }
  num('fixed_lot', 0.01, numSetting('cap_fixed_lot'));
  num('risk_percent', 0.1, numSetting('cap_risk_percent'));
  num('rr', 0.5, 5);
  num('max_daily_loss_pct', 0.5, numSetting('cap_daily_loss_pct'));
  num('max_drawdown_pct', 1, numSetting('cap_drawdown_pct'));
  num('max_spread_points', 5, numSetting('cap_max_spread_points'));
  num('max_open_trades', 1, numSetting('cap_max_open_trades'));
  num('session_start_hour', 0, 23); num('session_end_hour', 1, 24);
  for (const k of ['use_m1_entries', 'use_trailing', 'use_breakeven']) if (input[k] !== undefined) r[k] = !!input[k];
  r.max_open_trades = Math.round(r.max_open_trades);
  if (r.session_end_hour <= r.session_start_hour) throw bad('session end must be after session start');
  return r;
}

// ---------- VPS / commands ----------
function queueCommand(vpsId, deploymentId, type) {
  run("DELETE FROM commands WHERE deployment_id=? AND type=? AND status='pending'", deploymentId, type);
  run('INSERT INTO commands(vps_id,deployment_id,type,created_at) VALUES(?,?,?,?)', vpsId, deploymentId, type, now());
}
function pickVps() {
  return q(`SELECT v.*, (SELECT COUNT(*) FROM ea_deployments d WHERE d.vps_id=v.id) AS load FROM vps_instances v WHERE v.status='online' ORDER BY load ASC`)
    .find(v => v.load < v.capacity);
}
function commandPayload(c) {
  const d = q1('SELECT * FROM ea_deployments WHERE id=?', c.deployment_id);
  const out = { id: c.id, type: c.type, deployment_id: c.deployment_id };
  if (!d) return out;
  const a = q1('SELECT * FROM mt5_accounts WHERE id=?', d.mt5_account_id);
  if (a && (c.type === 'deploy' || c.type === 'config' || c.type === 'restart' || c.type === 'start' || c.type === 'enable_autotrading')) {
    out.config = { instrument: a.instrument, settings: JSON.parse(a.settings_json), ea_version: setting('ea_version'), enabled: setting('ea_enabled') === '1' };
    // Credentials are decrypted only for the authenticated VPS agent that owns this deployment, over TLS.
    if (c.type !== 'config') out.account = { login: a.login, server: a.server, password: sec.decrypt(a.password_enc, MASTER) };
  }
  return out;
}

// ---------- dashboard maths ----------
function startOfDay(ts, offMin) { const o = offMin * 60e3; return Math.floor((ts + o) / DAY) * DAY - o; }
function bucketPnl(trades, keyFn, count, stepFn) {
  const m = new Map();
  for (const t of trades) { const k = keyFn(t.close_time); m.set(k, (m.get(k) || 0) + t.profit + t.swap + t.commission); }
  const out = []; let k = keyFn(now());
  for (let i = 0; i < count; i++) { out.unshift({ t: k, pnl: +(m.get(k) || 0).toFixed(2) }); k = stepFn(k); }
  return out;
}
function dashboardFor(account) {
  const offMin = numSetting('tz_offset_minutes');
  const st = q1('SELECT * FROM account_state WHERE mt5_account_id=?', account.id);
  const dep = q1('SELECT * FROM ea_deployments WHERE mt5_account_id=?', account.id);
  const vps = dep?.vps_id ? q1('SELECT id,name,region,status,cpu_pct,ram_pct,last_seen FROM vps_instances WHERE id=?', dep.vps_id) : null;
  const closed = q('SELECT * FROM trades WHERE mt5_account_id=? AND close_time IS NOT NULL ORDER BY close_time DESC', account.id);
  const sod = startOfDay(now(), offMin);
  const net = t => t.profit + t.swap + t.commission;
  const daily = closed.filter(t => t.close_time >= sod).reduce((s, t) => s + net(t), 0);
  const total = closed.reduce((s, t) => s + net(t), 0);
  const snaps = q('SELECT ts,balance,equity FROM snapshots WHERE mt5_account_id=? AND ts>? ORDER BY ts ASC', account.id, now() - 30 * DAY);
  const step = Math.max(1, Math.ceil(snaps.length / 300));
  const curve = snaps.filter((_, i) => i % step === 0 || i === snaps.length - 1);
  const peakRow = q1('SELECT MAX(equity) p FROM snapshots WHERE mt5_account_id=?', account.id);
  const peak = Math.max(peakRow?.p || 0, st?.equity || 0);
  const dd = st && peak > 0 ? Math.max(0, (peak - st.equity) / peak * 100) : null;
  const dayKey = ts => startOfDay(ts, offMin);
  const weekKey = ts => { const d = startOfDay(ts, offMin); const dow = new Date(d + offMin * 60e3).getUTCDay(); return d - ((dow + 6) % 7) * DAY; };
  const monthKey = ts => { const d = new Date(ts + offMin * 60e3); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1) - offMin * 60e3; };
  const prevMonth = k => { const d = new Date(k + offMin * 60e3); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1) - offMin * 60e3; };
  const stale = st && now() - st.updated_at > 5 * 60e3;
  let eaStatus = 'not_deployed';
  if (dep) {
    eaStatus = dep.status;
    if (vps && vps.status !== 'online') eaStatus = 'disconnected';
    else if (stale && dep.status === 'running') eaStatus = 'disconnected';
  }
  return {
    account: { id: account.id, login: account.login, server: account.server, broker: st?.broker || account.broker, instrument: account.instrument, status: account.status, settings: JSON.parse(account.settings_json) },
    live: st ? { balance: st.balance, equity: st.equity, margin: st.margin, free_margin: st.free_margin, floating: st.floating, currency: st.currency, leverage: st.leverage, connected: !!st.connected && !stale, updated_at: st.updated_at, positions: JSON.parse(st.positions_json || '[]') } : null,
    stats: { daily_pnl: st ? +daily.toFixed(2) : null, total_profit: st ? +total.toFixed(2) : null, drawdown_pct: dd === null ? null : +dd.toFixed(2), closed_trades: closed.length },
    ea: dep ? { id: dep.id, status: eaStatus, desired_state: dep.desired_state, autotrading: !!dep.autotrading, terminal_connected: !!dep.terminal_connected, last_error: dep.last_error, last_report_at: dep.last_report_at, version: dep.ea_version } : null,
    vps: vps ? { name: vps.name, region: vps.region, status: vps.status, cpu_pct: vps.cpu_pct, ram_pct: vps.ram_pct, last_seen: vps.last_seen } : null,
    equity_curve: curve,
    performance: {
      daily: bucketPnl(closed, dayKey, 30, k => k - DAY),
      weekly: bucketPnl(closed, weekKey, 12, k => k - 7 * DAY),
      monthly: bucketPnl(closed, monthKey, 12, prevMonth)
    },
    history: closed.slice(0, 100)
  };
}

// ---------- PayFast ----------
const PF = () => ({
  id: process.env.PAYFAST_MERCHANT_ID, key: process.env.PAYFAST_MERCHANT_KEY, pass: process.env.PAYFAST_PASSPHRASE || '',
  sandbox: process.env.PAYFAST_SANDBOX !== 'false'
});
const pfConfigured = () => { const p = PF(); return !!(p.id && p.key); };
const pfEnc = s => encodeURIComponent(String(s).trim()).replace(/[!'()*~]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase()).replace(/%20/g, '+');
function pfSignature(pairs, pass) {
  let s = pairs.filter(([, v]) => v !== '' && v !== undefined && v !== null).map(([k, v]) => `${k}=${pfEnc(v)}`).join('&');
  if (pass) s += `&passphrase=${pfEnc(pass)}`;
  return crypto.createHash('md5').update(s).digest('hex');
}

// ---------- router ----------
const routes = [];
function route(method, pattern, auth, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z_]+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
  routes.push({ method, re, keys, auth, handler });
}
const idParam = v => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw bad('Invalid id'); return n; };
const publicUser = u => {
  const s = subOf(u.id);
  return {
    id: u.id, email: u.email, name: u.name, phone: u.phone, is_admin: u.is_admin, email_verified: !!u.email_verified, created_at: u.created_at,
    subscription: s ? { status: s.status === 'active' && s.ends_at <= now() ? 'expired' : s.status, ends_at: s.ends_at, auto_renew: !!s.auto_renew } : null,
    subscription_active: hasActiveSub(u.id)
  };
};
const requireSub = u => { if (!hasActiveSub(u.id)) throw bad('An active ALGOEA PREMIUM subscription is required', 402); };
const ownAccount = (u, id) => {
  const a = q1('SELECT * FROM mt5_accounts WHERE id=? AND user_id=?', idParam(id), u.id);
  if (!a) throw bad('MT5 account not found', 404);
  return a;
};
const accountView = a => {
  const d = q1('SELECT id,status,desired_state,vps_id FROM ea_deployments WHERE mt5_account_id=?', a.id);
  return { id: a.id, login: a.login, server: a.server, broker: a.broker, instrument: a.instrument, status: a.status, settings: JSON.parse(a.settings_json), created_at: a.created_at, deployment: d ? { id: d.id, status: d.status, desired_state: d.desired_state } : null };
};

// ===== public =====
route('GET', '/api/config', 'none', () => ({
  plan: { name: 'ALGOEA PREMIUM', price_cents: numSetting('price_cents'), currency: setting('currency'), interval: 'month' },
  instruments: setting('allowed_instruments').split(','), signups_open: setting('signups_open') === '1',
  payments_configured: pfConfigured(), caps: {
    risk_percent: numSetting('cap_risk_percent'), fixed_lot: numSetting('cap_fixed_lot'), daily_loss_pct: numSetting('cap_daily_loss_pct'),
    drawdown_pct: numSetting('cap_drawdown_pct'), max_spread_points: numSetting('cap_max_spread_points'), max_open_trades: numSetting('cap_max_open_trades')
  }, defaults: DEFAULT_RISK
}));

// ===== auth =====
route('POST', '/api/auth/register', 'none', async ({ body, ip }) => {
  if (!sec.rateLimit('reg:' + ip, 10, 3600e3)) throw bad('Too many attempts, try later', 429);
  if (setting('signups_open') !== '1') throw bad('Registration is currently closed', 403);
  const name = str(body.name, 2, 80, 'Name');
  const email = str(body.email, 5, 200, 'Email').toLowerCase();
  if (!EMAIL_RE.test(email)) throw bad('Invalid email address');
  const pw = str(body.password, 10, 200, 'Password');
  if (!/[a-z]/i.test(pw) || !/\d/.test(pw)) throw bad('Password must be at least 10 characters with letters and numbers');
  if (!body.accept_terms) throw bad('You must accept the Terms and Privacy Policy');
  const msg = { ok: true, message: 'If this email can be registered, a verification link has been sent.' };
  if (q1('SELECT 1 x FROM users WHERE email=?', email)) return msg;
  const r = run('INSERT INTO users(email,name,password_hash,created_at) VALUES(?,?,?,?)', email, name, await sec.hashPassword(pw), now());
  await sendEmailToken(Number(r.lastInsertRowid), email, 'verify');
  audit(Number(r.lastInsertRowid), 'register', email, null, ip);
  return msg;
});
async function sendEmailToken(userId, email, purpose) {
  const token = sec.randomToken(32);
  run('INSERT INTO email_tokens(token_hash,user_id,purpose,expires_at) VALUES(?,?,?,?)', sec.sha256(token), userId, purpose, now() + (purpose === 'verify' ? DAY : 3600e3));
  const link = `${APP_URL}/#/${purpose === 'verify' ? 'verify' : 'reset'}?token=${token}`;
  if (purpose === 'verify') await mail(email, 'Verify your ALGOEA email', `Welcome to ALGOEA.\n\nVerify your email: ${link}\n\nThis link expires in 24 hours.`);
  else await mail(email, 'Reset your ALGOEA password', `A password reset was requested.\n\nReset link: ${link}\n\nThis link expires in 1 hour. If you did not request it, ignore this email.`);
}
function consumeToken(token, purpose) {
  const t = q1('SELECT * FROM email_tokens WHERE token_hash=? AND purpose=?', sec.sha256(String(token || '')), purpose);
  if (!t || t.used || t.expires_at < now()) throw bad('This link is invalid or has expired');
  run('UPDATE email_tokens SET used=1 WHERE token_hash=?', t.token_hash);
  return t.user_id;
}
route('POST', '/api/auth/verify', 'none', ({ body, ip }) => {
  const uid = consumeToken(body.token, 'verify');
  run('UPDATE users SET email_verified=1 WHERE id=?', uid);
  const u = q1('SELECT * FROM users WHERE id=?', uid);
  if (u.email.toLowerCase() === ADMIN_EMAIL) {
    run('INSERT OR IGNORE INTO administrators(user_id,granted_at) VALUES(?,?)', uid, now());
    audit(uid, 'admin_granted', u.email, null, ip);
  }
  audit(uid, 'email_verified', u.email, null, ip);
  return { ok: true };
});
route('POST', '/api/auth/resend', 'none', async ({ body, ip }) => {
  if (!sec.rateLimit('resend:' + ip, 5, 3600e3)) throw bad('Too many attempts', 429);
  const u = q1('SELECT * FROM users WHERE email=?', String(body.email || '').toLowerCase());
  if (u && !u.email_verified) await sendEmailToken(u.id, u.email, 'verify');
  return { ok: true, message: 'If the account exists and is unverified, a new link has been sent.' };
});
route('POST', '/api/auth/login', 'none', async ({ body, req, res, ip }) => {
  const email = String(body.email || '').toLowerCase().trim();
  if (!sec.rateLimit('login:' + ip, 20, 900e3) || !sec.rateLimit('loginE:' + email, 6, 900e3)) throw bad('Too many login attempts. Try again in 15 minutes.', 429);
  const u = q1('SELECT * FROM users WHERE email=?', email);
  const ok = await sec.verifyPassword(String(body.password || ''), u ? u.password_hash : 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA');
  if (!u || !ok) { audit(u?.id, 'login_failed', email, null, ip); throw bad('Invalid email or password', 401); }
  if (!u.email_verified) throw bad('Please verify your email before logging in', 403);
  if (u.status !== 'active') throw bad('This account is suspended. Contact support.', 403);
  const token = createSession(u.id, req);
  setCookie(res, token);
  audit(u.id, 'login', email, null, ip);
  const uu = { ...u, is_admin: !!q1('SELECT 1 x FROM administrators WHERE user_id=?', u.id) };
  return { user: publicUser(uu), ...(body.client === 'mobile' ? { token } : {}) };
});
function setCookie(res, token, clear) {
  res.setHeader('Set-Cookie', `algoea_session=${clear ? '' : token}; HttpOnly; SameSite=Strict; Path=/; ${clear ? 'Max-Age=0' : 'Max-Age=' + 30 * 86400}${SECURE_COOKIE ? '; Secure' : ''}`);
}
route('POST', '/api/auth/logout', 'user', ({ user, res }) => { run('DELETE FROM sessions WHERE token_hash=?', user._sessionHash); setCookie(res, '', true); return { ok: true }; });
route('POST', '/api/auth/logout-all', 'user', ({ user, res, ip }) => { run('DELETE FROM sessions WHERE user_id=?', user.id); setCookie(res, '', true); audit(user.id, 'logout_all', null, null, ip); return { ok: true }; });
route('POST', '/api/auth/forgot', 'none', async ({ body, ip }) => {
  if (!sec.rateLimit('forgot:' + ip, 5, 3600e3)) throw bad('Too many attempts', 429);
  const u = q1('SELECT * FROM users WHERE email=?', String(body.email || '').toLowerCase());
  if (u) await sendEmailToken(u.id, u.email, 'reset');
  return { ok: true, message: 'If that email is registered, a reset link has been sent.' };
});
route('POST', '/api/auth/reset', 'none', async ({ body, ip }) => {
  const pw = str(body.password, 10, 200, 'Password');
  if (!/[a-z]/i.test(pw) || !/\d/.test(pw)) throw bad('Password must be at least 10 characters with letters and numbers');
  const uid = consumeToken(body.token, 'reset');
  run('UPDATE users SET password_hash=?, email_verified=1 WHERE id=?', await sec.hashPassword(pw), uid);
  const u = q1('SELECT * FROM users WHERE id=?', uid);
  if (u.email.toLowerCase() === ADMIN_EMAIL) run('INSERT OR IGNORE INTO administrators(user_id,granted_at) VALUES(?,?)', uid, now());
  run('DELETE FROM sessions WHERE user_id=?', uid);
  audit(uid, 'password_reset', null, null, ip);
  return { ok: true };
});

// ===== profile =====
route('GET', '/api/me', 'user', ({ user }) => ({ user: publicUser(user), unread: q1('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0', user.id).c }));
route('PUT', '/api/me', 'user', ({ user, body }) => {
  const name = str(body.name, 2, 80, 'Name');
  const phone = body.phone ? str(String(body.phone), 5, 30, 'Phone') : null;
  run('UPDATE users SET name=?, phone=? WHERE id=?', name, phone, user.id);
  return { ok: true };
});
route('POST', '/api/me/password', 'user', async ({ user, body, ip }) => {
  if (!(await sec.verifyPassword(String(body.current_password || ''), user.password_hash))) throw bad('Current password is incorrect', 403);
  const pw = str(body.new_password, 10, 200, 'New password');
  if (!/[a-z]/i.test(pw) || !/\d/.test(pw)) throw bad('Password must be at least 10 characters with letters and numbers');
  run('UPDATE users SET password_hash=? WHERE id=?', await sec.hashPassword(pw), user.id);
  run('DELETE FROM sessions WHERE user_id=? AND token_hash<>?', user.id, user._sessionHash);
  audit(user.id, 'password_changed', null, null, ip);
  return { ok: true };
});
route('GET', '/api/me/sessions', 'user', ({ user }) => ({
  sessions: q('SELECT created_at,expires_at,ip,user_agent,token_hash FROM sessions WHERE user_id=? ORDER BY created_at DESC', user.id)
    .map(s => ({ created_at: s.created_at, ip: s.ip, user_agent: s.user_agent, current: s.token_hash === user._sessionHash }))
}));
route('GET', '/api/notifications', 'user', ({ user }) => ({ notifications: q('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50', user.id) }));
route('POST', '/api/notifications/read', 'user', ({ user }) => { run('UPDATE notifications SET read=1 WHERE user_id=?', user.id); return { ok: true }; });

// ===== billing =====
route('GET', '/api/billing', 'user', ({ user }) => ({
  subscription: publicUser(user).subscription,
  plan: { name: 'ALGOEA PREMIUM', price_cents: numSetting('price_cents'), currency: setting('currency') },
  payments: q('SELECT id,provider,provider_ref,amount_cents,currency,status,created_at FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 100', user.id),
  payments_configured: pfConfigured()
}));
route('POST', '/api/billing/checkout', 'user', ({ user }) => {
  if (!pfConfigured()) throw bad('Online payments are not configured yet. Contact support to subscribe.', 503);
  const p = PF(), price = (numSetting('price_cents') / 100).toFixed(2);
  const pr = run("INSERT INTO payments(user_id,provider,provider_ref,amount_cents,currency,status,created_at) VALUES(?, 'payfast', NULL, ?, ?, 'pending', ?)", user.id, numSetting('price_cents'), setting('currency'), now());
  const mid = 'ALGO-' + pr.lastInsertRowid;
  const d = new Date(); const bd = d.toISOString().slice(0, 10);
  const pairs = [
    ['merchant_id', p.id], ['merchant_key', p.key],
    ['return_url', APP_URL + '/#/dashboard?paid=1'], ['cancel_url', APP_URL + '/#/pricing?cancelled=1'], ['notify_url', APP_URL + '/api/billing/payfast/itn'],
    ['name_first', user.name.split(' ')[0]], ['email_address', user.email],
    ['m_payment_id', mid], ['amount', price], ['item_name', 'ALGOEA PREMIUM - Monthly'],
    ['subscription_type', '1'], ['billing_date', bd], ['recurring_amount', price], ['frequency', '3'], ['cycles', '0']
  ];
  const fields = Object.fromEntries(pairs); fields.signature = pfSignature(pairs, p.pass);
  return { action: `https://${p.sandbox ? 'sandbox.payfast.co.za' : 'www.payfast.co.za'}/eng/process`, fields };
});
route('POST', '/api/billing/cancel', 'user', async ({ user, ip }) => {
  const s = subOf(user.id);
  if (!s || s.status !== 'active') throw bad('No active subscription');
  if (s.payfast_token && pfConfigured()) {
    const p = PF(), ts = new Date().toISOString().slice(0, 19);
    const sig = pfSignature([['merchant-id', p.id], ['passphrase', p.pass], ['timestamp', ts], ['version', 'v1']], '');
    const r = await fetch(`https://api.payfast.co.za/subscriptions/${encodeURIComponent(s.payfast_token)}/cancel${p.sandbox ? '?testing=true' : ''}`, {
      method: 'PUT', headers: { 'merchant-id': p.id, version: 'v1', timestamp: ts, signature: sig }
    });
    if (!r.ok) { syslog('error', 'payfast', `Cancel failed for user ${user.id}: HTTP ${r.status}`); throw bad('Could not cancel with the payment provider. Contact support.', 502); }
  }
  run('UPDATE subscriptions SET auto_renew=0 WHERE user_id=?', user.id);
  audit(user.id, 'auto_renew_off', null, null, ip);
  return { ok: true, message: 'Automatic renewal cancelled. Access continues until the end of the paid period.' };
});
// PayFast Instant Transaction Notification. Activation happens ONLY here (or by an admin's manual verification).
route('POST', '/api/billing/payfast/itn', 'itn', async ({ raw }) => {
  const pairs = [...new URLSearchParams(raw).entries()];
  const get = k => pairs.find(([x]) => x === k)?.[1];
  const p = PF();
  if (!pfConfigured()) return 'ignored';
  const sig = pfSignature(pairs.filter(([k]) => k !== 'signature'), p.pass);
  if (!sec.safeEqual(sig, get('signature') || '')) { syslog('warn', 'payfast', 'ITN rejected: bad signature'); return 'bad signature'; }
  // server-to-server confirmation with PayFast
  try {
    const vr = await fetch(`https://${p.sandbox ? 'sandbox.payfast.co.za' : 'www.payfast.co.za'}/eng/query/validate`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: pairs.filter(([k]) => k !== 'signature').map(([k, v]) => `${k}=${pfEnc(v)}`).join('&') + '&signature=' + sig
    });
    if ((await vr.text()).trim() !== 'VALID') { syslog('warn', 'payfast', 'ITN rejected: PayFast validation failed'); return 'invalid'; }
  } catch (e) { syslog('error', 'payfast', 'ITN validation error ' + e.message); throw new HttpError(500, 'validation unavailable'); }
  const pfId = get('pf_payment_id'), status = get('payment_status'), token = get('token');
  const mid = get('m_payment_id') || '';
  let pending = mid.startsWith('ALGO-') ? q1('SELECT * FROM payments WHERE id=?', Number(mid.slice(5))) : null;
  let userId = pending?.user_id;
  if (!userId && token) userId = q1('SELECT user_id FROM subscriptions WHERE payfast_token=?', token)?.user_id;
  if (!userId || !pfId) return 'unknown';
  if (q1("SELECT 1 x FROM payments WHERE provider='payfast' AND provider_ref=?", pfId)) return 'duplicate';
  const gross = Math.round(parseFloat(get('amount_gross') || '0') * 100);
  if (status === 'COMPLETE') {
    if (gross !== numSetting('price_cents')) { syslog('error', 'payfast', `Amount mismatch ${gross} for user ${userId}`); return 'amount mismatch'; }
    if (pending && !pending.provider_ref) run("UPDATE payments SET provider_ref=?, status='complete' WHERE id=?", pfId, pending.id);
    else run("INSERT INTO payments(user_id,provider,provider_ref,amount_cents,currency,status,created_at) VALUES(?, 'payfast', ?, ?, ?, 'complete', ?)", userId, pfId, gross, setting('currency'), now());
    extendSubscription(userId, 1, token);
    notify(userId, 'Payment received', 'Thank you. Your ALGOEA PREMIUM subscription is active.');
    audit(userId, 'payment_complete', pfId, { gross });
  } else if (status === 'CANCELLED') {
    run("UPDATE subscriptions SET auto_renew=0 WHERE user_id=?", userId);
  } else if (pending) run("UPDATE payments SET status='failed' WHERE id=? AND provider_ref IS NULL", pending.id);
  return 'ok';
});

// ===== MT5 =====
route('GET', '/api/mt5', 'user', ({ user }) => ({ accounts: q('SELECT * FROM mt5_accounts WHERE user_id=? ORDER BY id', user.id).map(accountView) }));
route('POST', '/api/mt5', 'user', ({ user, body, ip }) => {
  requireSub(user);
  if (q1('SELECT COUNT(*) c FROM mt5_accounts WHERE user_id=?', user.id).c >= numSetting('max_mt5_accounts')) throw bad('MT5 account limit reached for your plan');
  const login = str(String(body.login ?? ''), 4, 12, 'MT5 login');
  if (!/^\d+$/.test(login)) throw bad('MT5 login must be numeric');
  const server = str(body.server, 2, 80, 'Broker server');
  if (!/^[\w .\-]+$/.test(server)) throw bad('Broker server contains invalid characters');
  const password = str(body.password, 1, 100, 'MT5 password');
  const instrument = String(body.instrument || 'XAUUSD').toUpperCase();
  if (!setting('allowed_instruments').split(',').includes(instrument)) throw bad('Instrument not allowed');
  const settings = validateRisk(body.settings || {});
  try {
    const r = run('INSERT INTO mt5_accounts(user_id,login,server,broker,password_enc,instrument,settings_json,created_at) VALUES(?,?,?,?,?,?,?,?)',
      user.id, login, server, body.broker ? str(body.broker, 1, 80, 'Broker') : null, sec.encrypt(password, MASTER), instrument, JSON.stringify(settings), now());
    audit(user.id, 'mt5_added', login, { server }, ip);
    return { account: accountView(q1('SELECT * FROM mt5_accounts WHERE id=?', Number(r.lastInsertRowid))) };
  } catch (e) { if (/UNIQUE/.test(e.message)) throw bad('This MT5 account is already added'); throw e; }
});
route('PUT', '/api/mt5/:id/settings', 'user', ({ user, params, body, ip }) => {
  requireSub(user);
  const a = ownAccount(user, params.id);
  const settings = validateRisk(body.settings || {}, JSON.parse(a.settings_json));
  let instrument = a.instrument;
  if (body.instrument) { instrument = String(body.instrument).toUpperCase(); if (!setting('allowed_instruments').split(',').includes(instrument)) throw bad('Instrument not allowed'); }
  run('UPDATE mt5_accounts SET settings_json=?, instrument=? WHERE id=?', JSON.stringify(settings), instrument, a.id);
  const d = q1('SELECT * FROM ea_deployments WHERE mt5_account_id=?', a.id);
  if (d?.vps_id) queueCommand(d.vps_id, d.id, 'config');
  audit(user.id, 'mt5_settings', a.login, settings, ip);
  return { ok: true, settings };
});
route('POST', '/api/mt5/:id/deploy', 'user', ({ user, params, ip }) => {
  requireSub(user);
  if (setting('ea_enabled') !== '1') throw bad('IRON SCALPING deployments are temporarily disabled by the administrator', 503);
  const a = ownAccount(user, params.id);
  let d = q1('SELECT * FROM ea_deployments WHERE mt5_account_id=?', a.id);
  let vpsId = d?.vps_id;
  if (vpsId && q1("SELECT status FROM vps_instances WHERE id=?", vpsId)?.status === 'disabled') vpsId = null;
  if (!vpsId) { const v = pickVps(); if (!v) throw bad('No hosting capacity is available right now. Please try again shortly or contact support.', 503); vpsId = v.id; }
  if (!d) {
    const r = run("INSERT INTO ea_deployments(user_id,mt5_account_id,vps_id,ea_version,status,desired_state,created_at) VALUES(?,?,?,?,'queued','running',?)", user.id, a.id, vpsId, setting('ea_version'), now());
    d = { id: Number(r.lastInsertRowid) };
  } else run("UPDATE ea_deployments SET vps_id=?, ea_version=?, status='queued', desired_state='running', last_error=NULL WHERE id=?", vpsId, setting('ea_version'), d.id);
  queueCommand(vpsId, d.id, 'deploy');
  audit(user.id, 'deploy_requested', a.login, { deployment: d.id, vps: vpsId }, ip);
  return { ok: true, deployment_id: d.id };
});
route('DELETE', '/api/mt5/:id', 'user', ({ user, params, ip }) => {
  const a = ownAccount(user, params.id);
  const d = q1('SELECT * FROM ea_deployments WHERE mt5_account_id=?', a.id);
  if (d?.vps_id) queueCommand(d.vps_id, d.id, 'remove');
  run('UPDATE mt5_accounts SET password_enc=? WHERE id=?', '', a.id);
  run('DELETE FROM mt5_accounts WHERE id=?', a.id);
  audit(user.id, 'mt5_removed', a.login, null, ip);
  return { ok: true };
});
const ACTIONS = ['start', 'stop', 'restart', 'enable_autotrading'];
function doControl(d, action) {
  if (!ACTIONS.includes(action)) throw bad('Unknown action');
  if (!d.vps_id) throw bad('EA is not deployed yet');
  run('UPDATE ea_deployments SET desired_state=? WHERE id=?', action === 'stop' ? 'stopped' : 'running', d.id);
  queueCommand(d.vps_id, d.id, action);
}
route('POST', '/api/deployments/:id/command', 'user', ({ user, params, body, ip }) => {
  requireSub(user);
  const d = q1('SELECT * FROM ea_deployments WHERE id=? AND user_id=?', idParam(params.id), user.id);
  if (!d) throw bad('Deployment not found', 404);
  if (body.action !== 'stop' && setting('ea_enabled') !== '1') throw bad('IRON SCALPING is temporarily disabled by the administrator', 503);
  doControl(d, body.action);
  audit(user.id, 'ea_' + body.action, String(d.id), null, ip);
  return { ok: true, message: 'Command queued. It will be applied within about 30 seconds.' };
});
route('GET', '/api/deployments/:id/logs', 'user', ({ user, params }) => {
  const d = q1('SELECT id FROM ea_deployments WHERE id=? AND user_id=?', idParam(params.id), user.id);
  if (!d) throw bad('Deployment not found', 404);
  return { logs: q('SELECT level,message,ts FROM ea_logs WHERE deployment_id=? ORDER BY id DESC LIMIT 100', d.id) };
});
route('GET', '/api/dashboard', 'user', ({ user, query }) => {
  const accounts = q('SELECT * FROM mt5_accounts WHERE user_id=? ORDER BY id', user.id);
  if (!accounts.length) return { accounts: [], data: null };
  const a = query.get('account') ? ownAccount(user, query.get('account')) : accounts[0];
  return { accounts: accounts.map(x => ({ id: x.id, login: x.login, server: x.server })), data: dashboardFor(a) };
});
route('GET', '/api/hosting', 'user', ({ user }) => {
  const rows = q('SELECT d.*, a.login, a.server, a.instrument FROM ea_deployments d JOIN mt5_accounts a ON a.id=d.mt5_account_id WHERE d.user_id=?', user.id);
  return {
    deployments: rows.map(d => {
      const v = d.vps_id ? q1('SELECT name,region,status,cpu_pct,ram_pct,last_seen FROM vps_instances WHERE id=?', d.vps_id) : null;
      return {
        id: d.id, login: d.login, server: d.server, instrument: d.instrument, status: d.status, desired_state: d.desired_state, ea_version: d.ea_version,
        terminal_connected: !!d.terminal_connected, autotrading: !!d.autotrading, last_error: d.last_error, last_report_at: d.last_report_at, vps: v,
        logs: q('SELECT level,message,ts FROM ea_logs WHERE deployment_id=? ORDER BY id DESC LIMIT 30', d.id)
      };
    })
  };
});

// ===== support =====
route('GET', '/api/support', 'user', ({ user }) => ({ tickets: q('SELECT * FROM tickets WHERE user_id=? ORDER BY updated_at DESC', user.id) }));
route('POST', '/api/support', 'user', ({ user, body }) => {
  if (!sec.rateLimit('ticket:' + user.id, 10, 3600e3)) throw bad('Too many tickets, try later', 429);
  const subject = str(body.subject, 3, 150, 'Subject'), msg = str(body.message, 5, 4000, 'Message');
  const r = run('INSERT INTO tickets(user_id,subject,created_at,updated_at) VALUES(?,?,?,?)', user.id, subject, now(), now());
  run('INSERT INTO ticket_messages(ticket_id,author_id,body,created_at) VALUES(?,?,?,?)', r.lastInsertRowid, user.id, msg, now());
  return { ok: true, id: Number(r.lastInsertRowid) };
});
route('GET', '/api/support/:id', 'user', ({ user, params }) => {
  const t = q1('SELECT * FROM tickets WHERE id=? AND user_id=?', idParam(params.id), user.id);
  if (!t) throw bad('Ticket not found', 404);
  return { ticket: t, messages: q('SELECT is_staff,body,created_at FROM ticket_messages WHERE ticket_id=? ORDER BY id', t.id) };
});
route('POST', '/api/support/:id/reply', 'user', ({ user, params, body }) => {
  const t = q1('SELECT * FROM tickets WHERE id=? AND user_id=?', idParam(params.id), user.id);
  if (!t) throw bad('Ticket not found', 404);
  run('INSERT INTO ticket_messages(ticket_id,author_id,body,created_at) VALUES(?,?,?,?)', t.id, user.id, str(body.message, 1, 4000, 'Message'), now());
  run("UPDATE tickets SET status='open', updated_at=? WHERE id=?", now(), t.id);
  return { ok: true };
});

// ===== admin =====
route('GET', '/api/admin/overview', 'admin', () => {
  const t = now();
  return {
    customers: q1('SELECT COUNT(*) c FROM users').c,
    active_subscriptions: q1("SELECT COUNT(*) c FROM subscriptions WHERE status='active' AND ends_at>?", t).c,
    expired_subscriptions: q1("SELECT COUNT(*) c FROM subscriptions WHERE status='expired' OR (status='active' AND ends_at<=?)", t).c,
    revenue_cents_30d: q1("SELECT COALESCE(SUM(amount_cents),0) s FROM payments WHERE status='complete' AND created_at>?", t - 30 * DAY).s,
    mt5_accounts: q1('SELECT COUNT(*) c FROM mt5_accounts').c,
    deployments_running: q1("SELECT COUNT(*) c FROM ea_deployments WHERE status='running'").c,
    deployments_error: q1("SELECT COUNT(*) c FROM ea_deployments WHERE status='error'").c,
    vps_online: q1("SELECT COUNT(*) c FROM vps_instances WHERE status='online'").c,
    vps_total: q1('SELECT COUNT(*) c FROM vps_instances').c,
    open_tickets: q1("SELECT COUNT(*) c FROM tickets WHERE status='open'").c
  };
});
route('GET', '/api/admin/users', 'admin', () => ({
  users: q(`SELECT u.id,u.email,u.name,u.phone,u.status,u.email_verified,u.created_at,s.status sub_status,s.ends_at,s.auto_renew,
    (SELECT COUNT(*) FROM mt5_accounts m WHERE m.user_id=u.id) mt5_count FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id ORDER BY u.id DESC LIMIT 500`)
}));
route('POST', '/api/admin/users/:id/status', 'admin', ({ user, params, body, ip }) => {
  const id = idParam(params.id);
  if (!['active', 'suspended'].includes(body.status)) throw bad('Invalid status');
  const target = q1('SELECT * FROM users WHERE id=?', id);
  if (!target) throw bad('User not found', 404);
  if (target.id === user.id) throw bad('You cannot suspend your own account');
  run('UPDATE users SET status=? WHERE id=?', body.status, id);
  if (body.status === 'suspended') { run('DELETE FROM sessions WHERE user_id=?', id); suspendAccess(id, 'Your account has been suspended by an administrator.'); }
  audit(user.id, 'admin_user_' + body.status, target.email, null, ip);
  return { ok: true };
});
route('POST', '/api/admin/users/:id/activate', 'admin', ({ user, params, body, ip }) => {
  const id = idParam(params.id);
  const target = q1('SELECT * FROM users WHERE id=?', id);
  if (!target) throw bad('User not found', 404);
  const months = Number(body.months);
  if (!Number.isInteger(months) || months < 1 || months > 12) throw bad('Months must be 1-12');
  const reference = str(body.reference, 3, 120, 'Payment reference (e.g. EFT proof reference)');
  run("INSERT INTO payments(user_id,provider,provider_ref,amount_cents,currency,status,note,created_at) VALUES(?, 'manual', ?, ?, ?, 'complete', ?, ?)",
    id, reference + '#' + sec.randomToken(4), numSetting('price_cents') * months, setting('currency'), `Verified manually by admin ${user.email}`, now());
  const ends = extendSubscription(id, months, null);
  notify(id, 'Subscription activated', 'Your ALGOEA PREMIUM subscription is active.');
  audit(user.id, 'admin_manual_activation', target.email, { months, reference }, ip);
  return { ok: true, ends_at: ends };
});
route('POST', '/api/admin/users/:id/revoke', 'admin', ({ user, params, ip }) => {
  const id = idParam(params.id);
  const target = q1('SELECT * FROM users WHERE id=?', id);
  if (!target) throw bad('User not found', 404);
  run("UPDATE subscriptions SET status='expired', ends_at=? WHERE user_id=?", now(), id);
  suspendAccess(id, 'Your licence has been revoked by an administrator.');
  audit(user.id, 'admin_licence_revoked', target.email, null, ip);
  return { ok: true };
});
route('GET', '/api/admin/payments', 'admin', () => ({
  payments: q('SELECT p.*, u.email FROM payments p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 500')
}));
route('GET', '/api/admin/mt5', 'admin', () => ({
  accounts: q(`SELECT a.id,a.login,a.server,a.broker,a.instrument,a.status,a.created_at,u.email,
    d.id deployment_id,d.status ea_status,d.desired_state,d.last_error,d.last_report_at,v.name vps_name,
    s.balance,s.equity,s.connected,s.updated_at state_at
    FROM mt5_accounts a JOIN users u ON u.id=a.user_id LEFT JOIN ea_deployments d ON d.mt5_account_id=a.id
    LEFT JOIN vps_instances v ON v.id=d.vps_id LEFT JOIN account_state s ON s.mt5_account_id=a.id ORDER BY a.id DESC LIMIT 500`)
}));
route('POST', '/api/admin/deployments/:id/command', 'admin', ({ user, params, body, ip }) => {
  const d = q1('SELECT * FROM ea_deployments WHERE id=?', idParam(params.id));
  if (!d) throw bad('Deployment not found', 404);
  doControl(d, body.action);
  audit(user.id, 'admin_ea_' + body.action, String(d.id), null, ip);
  return { ok: true };
});
route('GET', '/api/admin/vps', 'admin', () => ({
  vps: q(`SELECT v.id,v.name,v.region,v.capacity,v.status,v.cpu_pct,v.ram_pct,v.hostname,v.agent_version,v.last_seen,
    (SELECT COUNT(*) FROM ea_deployments d WHERE d.vps_id=v.id) deployments FROM vps_instances v ORDER BY v.id`)
}));
route('POST', '/api/admin/vps', 'admin', ({ user, body, ip }) => {
  const name = str(body.name, 2, 60, 'Name'); const cap = Number(body.capacity || 20);
  if (!Number.isInteger(cap) || cap < 1 || cap > 500) throw bad('Capacity must be 1-500');
  const key = 'vps_' + sec.randomToken(32);
  try {
    const r = run("INSERT INTO vps_instances(name,region,capacity,api_key_hash,status,created_at) VALUES(?,?,?,?, 'offline', ?)", name, body.region ? str(body.region, 1, 60, 'Region') : null, cap, sec.sha256(key), now());
    audit(user.id, 'vps_created', name, null, ip);
    return { id: Number(r.lastInsertRowid), api_key: key, note: 'Store this key on the VPS agent now. It is shown only once.' };
  } catch (e) { if (/UNIQUE/.test(e.message)) throw bad('A VPS with that name exists'); throw e; }
});
route('POST', '/api/admin/vps/:id', 'admin', ({ user, params, body, ip }) => {
  const id = idParam(params.id);
  if (body.status && !['online', 'offline', 'disabled'].includes(body.status)) throw bad('Invalid status');
  if (body.status === 'disabled' || body.status === 'offline') run('UPDATE vps_instances SET status=? WHERE id=?', body.status, id);
  if (body.capacity !== undefined) { const c = Number(body.capacity); if (!Number.isInteger(c) || c < 1 || c > 500) throw bad('Capacity must be 1-500'); run('UPDATE vps_instances SET capacity=? WHERE id=?', c, id); }
  audit(user.id, 'vps_updated', String(id), body, ip);
  return { ok: true };
});
route('POST', '/api/admin/vps/:id/rotate-key', 'admin', ({ user, params, ip }) => {
  const id = idParam(params.id), key = 'vps_' + sec.randomToken(32);
  run('UPDATE vps_instances SET api_key_hash=? WHERE id=?', sec.sha256(key), id);
  audit(user.id, 'vps_key_rotated', String(id), null, ip);
  return { api_key: key, note: 'Update the agent with this key. The old key no longer works.' };
});
const STRATEGY_KEYS = ['ea_version', 'ea_enabled', 'allowed_instruments', 'cap_risk_percent', 'cap_fixed_lot', 'cap_daily_loss_pct', 'cap_drawdown_pct', 'cap_max_spread_points', 'cap_max_open_trades'];
route('GET', '/api/admin/strategy', 'admin', () => ({ settings: Object.fromEntries(STRATEGY_KEYS.map(k => [k, setting(k)])) }));
route('PUT', '/api/admin/strategy', 'admin', ({ user, body, ip }) => {
  const s = body.settings || {};
  for (const k of Object.keys(s)) {
    if (!STRATEGY_KEYS.includes(k)) throw bad('Unknown setting ' + k);
    let v = String(s[k]).trim();
    if (k === 'ea_version' && !/^\d+\.\d+\.\d+$/.test(v)) throw bad('ea_version must look like 1.0.0');
    if (k === 'ea_enabled' && !['0', '1'].includes(v)) throw bad('ea_enabled must be 0 or 1');
    if (k === 'allowed_instruments') { v = v.toUpperCase().replace(/\s/g, ''); if (!/^[A-Z0-9.]{3,15}(,[A-Z0-9.]{3,15})*$/.test(v)) throw bad('Instruments must be comma separated symbols'); }
    if (k.startsWith('cap_') && !(Number(v) > 0 && Number(v) <= 1000)) throw bad(k + ' must be a positive number');
    run('UPDATE settings SET value=? WHERE key=?', v, k);
  }
  if (body.push_config) for (const d of q('SELECT * FROM ea_deployments WHERE vps_id IS NOT NULL')) {
    // clamp stored user settings to new caps
    const a = q1('SELECT * FROM mt5_accounts WHERE id=?', d.mt5_account_id);
    try { run('UPDATE mt5_accounts SET settings_json=? WHERE id=?', JSON.stringify(validateRisk(JSON.parse(a.settings_json), DEFAULT_RISK)), a.id); }
    catch { run('UPDATE mt5_accounts SET settings_json=? WHERE id=?', JSON.stringify(DEFAULT_RISK), a.id); }
    queueCommand(d.vps_id, d.id, 'config');
  }
  if (s.ea_enabled === '0') for (const d of q("SELECT * FROM ea_deployments WHERE vps_id IS NOT NULL AND desired_state='running'")) { run("UPDATE ea_deployments SET desired_state='stopped' WHERE id=?", d.id); queueCommand(d.vps_id, d.id, 'stop'); }
  audit(user.id, 'strategy_updated', null, s, ip);
  return { ok: true };
});
const PLATFORM_KEYS = ['price_cents', 'max_mt5_accounts', 'tz_offset_minutes', 'signups_open'];
route('GET', '/api/admin/settings', 'admin', () => ({ settings: Object.fromEntries(PLATFORM_KEYS.map(k => [k, setting(k)])) }));
route('PUT', '/api/admin/settings', 'admin', ({ user, body, ip }) => {
  const s = body.settings || {};
  for (const [k, raw] of Object.entries(s)) {
    if (!PLATFORM_KEYS.includes(k)) throw bad('Unknown setting ' + k);
    const n = Number(raw);
    if (!Number.isInteger(n)) throw bad(k + ' must be an integer');
    if (k === 'price_cents' && (n < 100 || n > 10000000)) throw bad('price out of range');
    if (k === 'max_mt5_accounts' && (n < 1 || n > 10)) throw bad('max accounts must be 1-10');
    if (k === 'tz_offset_minutes' && Math.abs(n) > 840) throw bad('invalid offset');
    if (k === 'signups_open' && ![0, 1].includes(n)) throw bad('signups_open must be 0 or 1');
    run('UPDATE settings SET value=? WHERE key=?', String(n), k);
  }
  audit(user.id, 'settings_updated', null, s, ip);
  return { ok: true };
});
route('GET', '/api/admin/tickets', 'admin', () => ({ tickets: q('SELECT t.*, u.email FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY (t.status="open") DESC, t.updated_at DESC LIMIT 200') }));
route('GET', '/api/admin/tickets/:id', 'admin', ({ params }) => {
  const t = q1('SELECT t.*, u.email FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?', idParam(params.id));
  if (!t) throw bad('Ticket not found', 404);
  return { ticket: t, messages: q('SELECT is_staff,body,created_at FROM ticket_messages WHERE ticket_id=? ORDER BY id', t.id) };
});
route('POST', '/api/admin/tickets/:id/reply', 'admin', ({ user, params, body, ip }) => {
  const t = q1('SELECT * FROM tickets WHERE id=?', idParam(params.id));
  if (!t) throw bad('Ticket not found', 404);
  run('INSERT INTO ticket_messages(ticket_id,author_id,is_staff,body,created_at) VALUES(?,?,1,?,?)', t.id, user.id, str(body.message, 1, 4000, 'Message'), now());
  run("UPDATE tickets SET status=?, updated_at=? WHERE id=?", body.close ? 'closed' : 'answered', now(), t.id);
  notify(t.user_id, 'Support reply', `Support replied to: ${t.subject}`);
  audit(user.id, 'ticket_reply', String(t.id), null, ip);
  return { ok: true };
});
route('GET', '/api/admin/logs', 'admin', ({ query }) => {
  const type = query.get('type') || 'system';
  if (type === 'audit') return { logs: q('SELECT a.id,a.action,a.target,a.meta,a.ip,a.ts,u.email FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 300') };
  if (type === 'ea') return { logs: q('SELECT l.id,l.level,l.message,l.ts,l.deployment_id FROM ea_logs l ORDER BY l.id DESC LIMIT 300') };
  return { logs: q('SELECT * FROM system_logs ORDER BY id DESC LIMIT 300') };
});

// ===== agent API (Windows VPS agents; authenticated by per-VPS key) =====
function agentAuth(req) {
  const a = req.headers.authorization || '';
  if (!a.startsWith('Bearer vps_')) return null;
  const v = q1('SELECT * FROM vps_instances WHERE api_key_hash=?', sec.sha256(a.slice(7)));
  return v && v.status !== 'disabled' ? v : null;
}
const nz = (v, d = null) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const ownDep = (vps, id) => {
  const d = q1('SELECT * FROM ea_deployments WHERE id=? AND vps_id=?', idParam(id), vps.id);
  if (!d) throw bad('Unknown deployment for this VPS', 404);
  return d;
};
route('POST', '/api/agent/heartbeat', 'agent', ({ vps, body }) => {
  run("UPDATE vps_instances SET status='online', cpu_pct=?, ram_pct=?, hostname=?, agent_version=?, last_seen=? WHERE id=?",
    nz(body.cpu_pct), nz(body.ram_pct), String(body.hostname || '').slice(0, 100), String(body.agent_version || '').slice(0, 20), now(), vps.id);
  for (const t of Array.isArray(body.terminals) ? body.terminals.slice(0, 500) : []) {
    const d = q1('SELECT * FROM ea_deployments WHERE id=? AND vps_id=?', nz(t.deployment_id, -1), vps.id);
    if (!d) continue;
    let status = ['running', 'stopped', 'error', 'deploying'].includes(t.status) ? t.status : d.status;
    const err = status === 'error' ? String(t.error || 'Unknown error').slice(0, 300) : null;
    run('UPDATE ea_deployments SET status=?, terminal_connected=?, autotrading=?, last_error=?, last_report_at=? WHERE id=?',
      status, t.mt5_connected ? 1 : 0, t.autotrading ? 1 : 0, err, now(), d.id);
    run('UPDATE mt5_accounts SET status=? WHERE id=?', status === 'error' ? 'error' : t.mt5_connected ? 'connected' : 'disconnected', d.mt5_account_id);
    if (d.status !== status) ws.push(d.user_id, { type: 'status' });
  }
  const cmds = q("SELECT * FROM commands WHERE vps_id=? AND status IN ('pending','sent') ORDER BY id LIMIT 20", vps.id);
  const out = [];
  for (const c of cmds) {
    if (c.status === 'sent' && now() - c.updated_at < 120e3) continue; // allow re-delivery if the agent crashed
    try { out.push(commandPayload(c)); run("UPDATE commands SET status='sent', updated_at=? WHERE id=?", now(), c.id); }
    catch (e) { run("UPDATE commands SET status='failed', result=?, updated_at=? WHERE id=?", e.message, now(), c.id); }
  }
  return { ok: true, commands: out, ea_enabled: setting('ea_enabled') === '1' };
});
route('POST', '/api/agent/command-result', 'agent', ({ vps, body }) => {
  const c = q1('SELECT * FROM commands WHERE id=? AND vps_id=?', nz(body.command_id, -1), vps.id);
  if (!c) throw bad('Unknown command', 404);
  run('UPDATE commands SET status=?, result=?, updated_at=? WHERE id=?', body.ok ? 'done' : 'failed', String(body.error || '').slice(0, 300), now(), c.id);
  const d = q1('SELECT * FROM ea_deployments WHERE id=?', c.deployment_id);
  if (d) {
    if (!body.ok && c.type !== 'remove') { run("UPDATE ea_deployments SET status='error', last_error=? WHERE id=?", String(body.error || 'Command failed').slice(0, 300), d.id); notify(d.user_id, 'EA command failed', `${c.type} failed: ${String(body.error || '').slice(0, 150)}`); }
    ws.push(d.user_id, { type: 'status' });
  }
  if (c.type === 'remove' && body.ok) run('DELETE FROM ea_deployments WHERE id=? AND NOT EXISTS (SELECT 1 FROM mt5_accounts WHERE id=ea_deployments.mt5_account_id)', c.deployment_id);
  return { ok: true };
});
route('POST', '/api/agent/account', 'agent', ({ vps, body }) => {
  const d = ownDep(vps, body.deployment_id);
  const acc = q1('SELECT * FROM mt5_accounts WHERE id=?', d.mt5_account_id);
  const positions = (Array.isArray(body.positions) ? body.positions : []).slice(0, 100).map(p => ({
    ticket: String(p.ticket), symbol: String(p.symbol || '').slice(0, 20), type: p.type === 'sell' ? 'sell' : 'buy', volume: nz(p.volume, 0),
    open_price: nz(p.open_price, 0), sl: nz(p.sl, 0), tp: nz(p.tp, 0), profit: nz(p.profit, 0), open_time: nz(p.open_time)
  }));
  const bal = nz(body.balance), eq = nz(body.equity);
  if (bal === null || eq === null) throw bad('balance and equity required');
  const t = now();
  run(`INSERT INTO account_state(mt5_account_id,balance,equity,margin,free_margin,floating,currency,leverage,broker,server,connected,positions_json,updated_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
       ON CONFLICT(mt5_account_id) DO UPDATE SET balance=excluded.balance,equity=excluded.equity,margin=excluded.margin,free_margin=excluded.free_margin,floating=excluded.floating,
       currency=excluded.currency,leverage=excluded.leverage,broker=excluded.broker,server=excluded.server,connected=excluded.connected,positions_json=excluded.positions_json,updated_at=excluded.updated_at`,
    acc.id, bal, eq, nz(body.margin, 0), nz(body.free_margin, 0), nz(body.floating, eq - bal), String(body.currency || '').slice(0, 8), nz(body.leverage), String(body.broker || '').slice(0, 100), String(body.server || '').slice(0, 100),
    body.connected === false ? 0 : 1, JSON.stringify(positions), t);
  const last = q1('SELECT ts FROM snapshots WHERE mt5_account_id=? ORDER BY ts DESC LIMIT 1', acc.id);
  if (!last || t - last.ts >= 60e3) run('INSERT INTO snapshots(mt5_account_id,ts,balance,equity) VALUES(?,?,?,?)', acc.id, t, bal, eq);
  if (body.broker && !acc.broker) run('UPDATE mt5_accounts SET broker=? WHERE id=?', String(body.broker).slice(0, 100), acc.id);
  ws.push(d.user_id, { type: 'account', account: acc.id });
  return { ok: true };
});
route('POST', '/api/agent/trades', 'agent', ({ vps, body }) => {
  const d = ownDep(vps, body.deployment_id);
  const acc = q1('SELECT * FROM mt5_accounts WHERE id=?', d.mt5_account_id);
  const st = db.prepare(`INSERT INTO trades(mt5_account_id,user_id,ticket,symbol,type,volume,open_time,close_time,open_price,close_price,profit,swap,commission)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(mt5_account_id,ticket) DO UPDATE SET close_time=excluded.close_time,close_price=excluded.close_price,profit=excluded.profit,swap=excluded.swap,commission=excluded.commission`);
  let n = 0;
  db.exec('BEGIN');
  try {
    for (const t of (Array.isArray(body.trades) ? body.trades : []).slice(0, 1000)) {
      if (t.ticket === undefined) continue;
      st.run(acc.id, acc.user_id, String(t.ticket), String(t.symbol || '').slice(0, 20), t.type === 'sell' ? 'sell' : 'buy', nz(t.volume, 0), nz(t.open_time), nz(t.close_time),
        nz(t.open_price, 0), nz(t.close_price, 0), nz(t.profit, 0), nz(t.swap, 0), nz(t.commission, 0));
      n++;
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  ws.push(d.user_id, { type: 'trades', account: acc.id });
  return { ok: true, upserted: n };
});
route('POST', '/api/agent/log', 'agent', ({ vps, body }) => {
  const d = ownDep(vps, body.deployment_id);
  for (const l of (Array.isArray(body.lines) ? body.lines : [{ level: body.level, message: body.message }]).slice(0, 50))
    run('INSERT INTO ea_logs(deployment_id,level,message,ts) VALUES(?,?,?,?)', d.id, ['info', 'warn', 'error'].includes(l.level) ? l.level : 'info', String(l.message || '').slice(0, 500), now());
  run('DELETE FROM ea_logs WHERE deployment_id=? AND id NOT IN (SELECT id FROM ea_logs WHERE deployment_id=? ORDER BY id DESC LIMIT 500)', d.id, d.id);
  return { ok: true };
});

// ---------- HTTP server ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8', '.mq5': 'text/plain; charset=utf-8' };
const PUBLIC = path.join(__dirname, 'public');
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:; form-action 'self' https://www.payfast.co.za https://sandbox.payfast.co.za; frame-ancestors 'none'; base-uri 'self'",
  ...(SECURE_COOKIE ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {})
};
function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, { ...SEC_HEADERS, ...(isObj ? { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } : {}), ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}
function readBody(req, limit = 1e6) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(bad('Payload too large', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function serveStatic(req, res, pathname) {
  let f = path.normalize(decodeURIComponent(pathname)).replace(/^(\.\.[/\\])+/, '');
  if (f === '/' || f === '\\' || f === '.') f = '/index.html';
  let full = path.join(PUBLIC, f);
  if (!full.startsWith(PUBLIC)) return send(res, 403, 'Forbidden');
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) full = path.join(PUBLIC, 'index.html');
  const ext = path.extname(full);
  send(res, 200, fs.readFileSync(full), { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ip = clientIp(req);
  try {
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
      return serveStatic(req, res, url.pathname);
    }
    const r = routes.find(x => x.method === req.method && x.re.test(url.pathname));
    if (!r) return send(res, 404, { error: 'Not found' });
    const m = url.pathname.match(r.re);
    const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
    const ctx = { req, res, params, query: url.searchParams, ip, user: null, body: {}, raw: '' };
    const mutating = req.method !== 'GET';
    if (r.auth === 'agent') {
      ctx.vps = agentAuth(req);
      if (!ctx.vps) return send(res, 401, { error: 'Invalid agent key' });
    } else if (r.auth !== 'itn') {
      ctx.user = userFromRequest(req);
      if (r.auth !== 'none' && !ctx.user) return send(res, 401, { error: 'Not authenticated' });
      if (r.auth === 'admin' && !ctx.user.is_admin) { audit(ctx.user.id, 'admin_denied', url.pathname, null, ip); return send(res, 403, { error: 'Administrator access required' }); }
      if (mutating) {
        const origin = req.headers.origin;
        if (origin) { try { if (new URL(origin).host !== req.headers.host) return send(res, 403, { error: 'Cross-origin request blocked' }); } catch { return send(res, 403, { error: 'Bad origin' }); } }
        if (!String(req.headers['content-type'] || '').includes('application/json') && req.method !== 'DELETE') return send(res, 415, { error: 'JSON required' });
      }
    }
    if (mutating && req.method !== 'DELETE') {
      ctx.raw = await readBody(req, r.auth === 'agent' ? 5e6 : 1e6);
      if (r.auth !== 'itn' && ctx.raw) { try { ctx.body = JSON.parse(ctx.raw); } catch { throw bad('Invalid JSON'); } }
      if (ctx.body === null || typeof ctx.body !== 'object' || Array.isArray(ctx.body)) ctx.body = {};
    }
    const out = await r.handler(ctx);
    if (r.auth === 'itn') return send(res, 200, String(out), { 'Content-Type': 'text/plain' });
    send(res, 200, out ?? { ok: true });
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error('[error]', req.method, req.url, e);
    syslog('error', 'server', `${req.method} ${url.pathname}: ${e.message}`);
    send(res, 500, { error: 'Internal server error' });
  }
});
ws = wsApi.attach(server, req => userFromRequest(req));
server.listen(PORT, () => {
  console.log(`ALGOEA running at ${APP_URL} (port ${PORT})`);
  console.log(`Administrator email: ${ADMIN_EMAIL} (register and verify this email to gain admin access)`);
  if (!pfConfigured()) console.log('PayFast not configured: set PAYFAST_* variables to take payments. Admin can verify manual payments meanwhile.');
  if (!process.env.RESEND_API_KEY) console.log('RESEND_API_KEY not set: emails are printed to this console (development mode).');
  sweep();
});
